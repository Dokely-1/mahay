import React, { useState, useEffect } from 'react';
import { TRANSLATIONS } from '../data';
import { Language } from '../types';

interface CountdownBannerProps {
  lang: Language;
  scrollToSection: (id: string) => void;
}

export default function CountdownBanner({ lang, scrollToSection }: CountdownBannerProps) {
  const t = TRANSLATIONS[lang];

  // Rolling 24h countdown state
  const [timeLeft, setTimeLeft] = useState({ hours: '00', minutes: '00', seconds: '00' });

  useEffect(() => {
    const STORAGE_KEY = 'rekany-countdown-end';
    let endTimeStr = localStorage.getItem(STORAGE_KEY);
    let endTime = endTimeStr ? parseInt(endTimeStr, 10) : 0;

    // If no end time or past, set a new 24h end time
    if (!endTime || endTime < Date.now()) {
      endTime = Date.now() + 24 * 60 * 60 * 1000;
      localStorage.setItem(STORAGE_KEY, endTime.toString());
    }

    const timer = setInterval(() => {
      const now = Date.now();
      let diff = endTime - now;

      if (diff <= 0) {
        // Reset 24 hours
        endTime = Date.now() + 24 * 60 * 60 * 1000;
        localStorage.setItem(STORAGE_KEY, endTime.toString());
        diff = endTime - now;
      }

      const h = Math.floor(diff / (1000 * 60 * 60));
      const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const s = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft({
        hours: String(h).padStart(2, '0'),
        minutes: String(m).padStart(2, '0'),
        seconds: String(s).padStart(2, '0')
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-6">
      <div className="bg-[#0f172a] rounded-2xl p-6 shadow-2xl shadow-blue-900/20 flex flex-col md:flex-row items-center justify-between gap-6 border border-white/10 select-none">
        
        {/* Left Side: Alert Title & Description */}
        <div className="flex items-center gap-4 text-center md:text-left">
          <div className="relative flex-shrink-0">
            <span className="absolute inline-flex h-full w-full rounded-full bg-red-500 opacity-75 animate-ping" />
            <div className="relative w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-xl shadow-inner select-none">
              🎓
            </div>
          </div>
          <div className="space-y-1">
            <div className="font-heading font-extrabold text-sm sm:text-base text-white flex items-center justify-center md:justify-start gap-2">
              <span>{lang === 'fr' ? "Offre de rentrée ultra-limitée !" : lang === 'mg' ? "Tolotra manokana voafetra !" : "Ultra-limited enrollment offer!"}</span>
              <span className="bg-red-500 text-white text-[9px] uppercase font-black px-2 py-0.5 rounded tracking-wider animate-pulse font-sans">
                {lang === 'en' ? "PROMO" : "PROMO"}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-gray-400 font-medium">
              {lang === 'fr' 
                ? "Toutes nos formations professionnelles d'excellence à seulement 50 000 Ar par cours" 
                : lang === 'mg'
                ? "Ny fiofanana matihanina rehetra amin'ny sarany 50 000 Ar monja isaky ny kôra"
                : "All our elite video courses are currently priced at only 50,000 Ar each"
              }
            </p>
          </div>
        </div>

        {/* Middle Side: Dynamic Timer Boxes */}
        <div className="flex items-center gap-2 bg-white/5 border border-white/5 p-3 rounded-xl select-none shrink-0">
          <div className="text-center">
            <div className="font-mono font-bold text-lg sm:text-xl text-white bg-white/5 w-12 h-12 flex items-center justify-center rounded-lg border border-white/10 leading-none">
              {timeLeft.hours}
            </div>
            <span className="text-[9px] text-white/40 mt-1 uppercase font-bold tracking-widest block">
              {lang === 'fr' ? 'Heures' : lang === 'mg' ? 'Ora' : 'Hours'}
            </span>
          </div>
          
          <span className="text-xl font-bold text-white/20 pb-3 font-mono inline-block">:</span>
          
          <div className="text-center">
            <div className="font-mono font-bold text-lg sm:text-xl text-white bg-white/5 w-12 h-12 flex items-center justify-center rounded-lg border border-white/10 leading-none font-sans">
              {timeLeft.minutes}
            </div>
            <span className="text-[9px] text-white/40 mt-1 uppercase font-bold tracking-widest block font-sans">
              {lang === 'fr' ? 'Min' : lang === 'mg' ? 'Min' : 'Min'}
            </span>
          </div>
          
          <span className="text-xl font-bold text-white/20 pb-3 font-mono inline-block">:</span>
          
          <div className="text-center">
            <div className="font-mono font-bold text-lg sm:text-xl text-red-400 bg-white/5 w-12 h-12 flex items-center justify-center rounded-lg border border-white/10 leading-none font-sans">
              {timeLeft.seconds}
            </div>
            <span className="text-[9px] text-red-400/80 mt-1 uppercase font-bold tracking-widest block font-sans">
              {lang === 'fr' ? 'Sec' : lang === 'mg' ? 'Sec' : 'Sec'}
            </span>
          </div>
        </div>

        {/* Right Side: Action Link */}
        <button
          onClick={() => scrollToSection('courses')}
          className="w-full md:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg uppercase tracking-wider hover:shadow-lg transition-all flex items-center justify-center gap-2 group border-none select-none cursor-pointer shrink-0"
        >
          <span>{lang === 'fr' ? "En profiter immédiatement" : lang === 'mg' ? "Hararaoty izany" : "Claim your offer"}</span>
          <span className="group-hover:translate-x-1 transition-transform">→</span>
        </button>

      </div>
    </div>
  );
}
