import React, { useState } from 'react';
import { TRANSLATIONS } from '../data';
import { Language } from '../types';

interface HeaderProps {
  lang: Language;
  setLang: (lang: Language) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  openEnrollModal: (courseName?: string) => void;
  scrollToSection: (id: string) => void;
}

export default function Header({
  lang,
  setLang,
  searchQuery,
  setSearchQuery,
  theme,
  toggleTheme,
  openEnrollModal,
  scrollToSection
}: HeaderProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);

  const t = TRANSLATIONS[lang];

  const handleNavClick = (sectionId: string) => {
    scrollToSection(sectionId);
    setSidebarOpen(false);
  };

  const currentLangLabel = {
    fr: { flag: '🇫🇷', code: 'FR', label: 'Français' },
    mg: { flag: '🇲🇬', code: 'MG', label: 'Malagasy' },
    en: { flag: '🇬🇧', code: 'EN', label: 'English' }
  };

  return (
    <>
      {/* Sidebar Overlay */}
      {sidebarOpen && (
        <div
          id="sidebarOverlay"
          onClick={() => setSidebarOpen(false)}
          className="fixed inset-0 bg-black/50 z-50 backdrop-blur-[2px] transition-all"
        />
      )}

      {/* Sidebar Drawer */}
      <aside
        className={`fixed top-0 left-0 h-screen w-[290px] bg-white dark:bg-gray-800 shadow-2xl z-55 transition-all duration-300 ease-in-out flex flex-col ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between p-5 border-b border-gray-200 dark:border-gray-700">
          <a href="#" className="flex items-center gap-1 font-heading font-bold text-xl text-primary dark:text-blue-400">
            <span>Rek'ANY</span>
            <span className="text-accent">.</span>
            <span>MG</span>
          </a>
          <button
            onClick={() => setSidebarOpen(false)}
            className="w-9 h-9 flex items-center justify-center border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700 rounded-lg text-gray-500 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600 transition-all font-bold"
          >
            ✕
          </button>
        </div>

        {/* Sidebar Search */}
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">🔍</span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.search_placeholder}
              className="w-full pl-9 pr-4 py-2 border-2 border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700 text-gray-800 dark:text-white rounded-full text-sm focus:outline-none focus:border-primary transition-all"
            />
          </div>
        </div>

        {/* Sidebar Menu Links */}
        <nav className="flex-1 overflow-y-auto py-4">
          <div className="text-[10px] font-bold tracking-widest uppercase text-gray-400 dark:text-gray-500 px-5 mb-2">
            {t.nav_menu}
          </div>
          <button
            onClick={() => handleNavClick('courses')}
            className="w-full text-left flex items-center gap-3 px-5 py-3 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-primary dark:hover:text-blue-400 transition-all border-l-4 border-transparent"
          >
            <span>📚</span>
            <span className="font-medium text-sm">{t.nav_courses}</span>
          </button>
          <button
            onClick={() => handleNavClick('features')}
            className="w-full text-left flex items-center gap-3 px-5 py-3 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-primary dark:hover:text-blue-400 transition-all border-l-4 border-transparent"
          >
            <span>⭐</span>
            <span className="font-medium text-sm">{t.nav_why}</span>
          </button>
          <button
            onClick={() => handleNavClick('pricing')}
            className="w-full text-left flex items-center gap-3 px-5 py-3 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-primary dark:hover:text-blue-400 transition-all border-l-4 border-transparent"
          >
            <span>💰</span>
            <span className="font-medium text-sm">{t.nav_pricing}</span>
          </button>
          <button
            onClick={() => handleNavClick('payment')}
            className="w-full text-left flex items-center gap-3 px-5 py-3 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-primary dark:hover:text-blue-400 transition-all border-l-4 border-transparent"
          >
            <span>📱</span>
            <span className="font-medium text-sm">{t.nav_payment}</span>
          </button>
          <button
            onClick={() => handleNavClick('faq')}
            className="w-full text-left flex items-center gap-3 px-5 py-3 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-primary dark:hover:text-blue-400 transition-all border-l-4 border-transparent"
          >
            <span>❓</span>
            <span className="font-medium text-sm">{t.nav_faq}</span>
          </button>
          <button
            onClick={() => handleNavClick('access-portal')}
            className="w-full text-left flex items-center gap-3 px-5 py-3 text-primary dark:text-blue-400 hover:bg-gray-50 dark:hover:bg-gray-700 font-bold transition-all border-l-4 border-transparent"
          >
            <span>🔐</span>
            <span className="text-sm">Espace Étudiant</span>
          </button>

          <div className="text-[10px] font-bold tracking-widest uppercase text-gray-400 dark:text-gray-500 px-5 mt-6 mb-2">
            {t.nav_courses_list}
          </div>
          <button
            onClick={() => handleNavClick('courses')}
            className="w-full text-left flex items-center gap-3 px-5 py-2.1 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 text-sm font-medium"
          >
            <span>🚀</span> <span>{t.course_marketing}</span>
          </button>
          <button
            onClick={() => handleNavClick('courses')}
            className="w-full text-left flex items-center gap-3 px-5 py-2.1 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 text-sm font-medium"
          >
            <span>📱</span> <span>{t.course_digital}</span>
          </button>
          <button
            onClick={() => handleNavClick('courses')}
            className="w-full text-left flex items-center gap-3 px-5 py-2.1 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 text-sm font-medium"
          >
            <span>🌐</span> <span>{t.course_reseau}</span>
          </button>
          <button
            onClick={() => handleNavClick('courses')}
            className="w-full text-left flex items-center gap-3 px-5 py-2.1 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 text-sm font-medium"
          >
            <span>💻</span> <span>{t.course_info}</span>
          </button>
          <button
            onClick={() => handleNavClick('courses')}
            className="w-full text-left flex items-center gap-3 px-5 py-2.1 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 text-sm font-medium"
          >
            <span>⌨️</span> <span>{t.course_dev}</span>
          </button>
          <button
            onClick={() => handleNavClick('courses')}
            className="w-full text-left flex items-center gap-3 px-5 py-2.1 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 text-sm font-medium"
          >
            <span>📊</span> <span>{t.course_bureau}</span>
          </button>
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t-2 border-gray-100 dark:border-gray-700 bg-white dark:bg-gray-800">
          <div className="text-[10px] font-bold tracking-widest uppercase text-gray-400 dark:text-gray-500 mb-2">
            🌍 Langue / Language
          </div>
          <div className="grid grid-cols-3 gap-1.5 mb-4">
            {(['fr', 'mg', 'en'] as Language[]).map((l) => (
              <button
                key={l}
                onClick={() => setLang(l)}
                className={`py-2 px-1 rounded-xl border text-xs font-semibold flex flex-col items-center justify-center gap-0.5 transition-all min-h-[50px] cursor-pointer ${
                  lang === l
                    ? 'border-primary bg-primary text-white shadow-md'
                    : 'border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:border-primary'
                }`}
              >
                <span className="text-base">{currentLangLabel[l].flag}</span>
                <span>{currentLangLabel[l].code}</span>
              </button>
            ))}
          </div>

          <div className="border-t border-gray-100 dark:border-gray-700 pt-3">
            <div
              onClick={toggleTheme}
              className="flex items-center justify-between p-2.5 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700 cursor-pointer hover:border-primary transition-all text-sm font-semibold text-gray-700 dark:text-gray-200"
            >
              <div className="flex items-center gap-2">
                <span>{theme === 'dark' ? '☀️' : '🌙'}</span>
                <span>{t.dark_mode}</span>
              </div>
              <div
                className={`w-11 h-6 rounded-full relative transition-all duration-300 ${
                  theme === 'dark' ? 'bg-primary' : 'bg-gray-300 dark:bg-gray-600'
                }`}
              >
                <div
                  className={`w-4.5 h-4.5 bg-white rounded-full absolute top-[3px] transition-all duration-300 ${
                    theme === 'dark' ? 'left-5.5' : 'left-1'
                  }`}
                />
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Sticky Navbar */}
      <nav id="navbar" className="sticky top-0 z-40 bg-white/95 dark:bg-gray-900/95 backdrop-blur-md border-b border-gray-200 dark:border-gray-800 transition-all">
        <div className="max-w-7xl mx-auto px-4 md:px-8 flex items-center justify-between h-[70px] gap-4">
          <div className="flex items-center gap-4">
            {/* Hamburger for mobile */}
            <button
              onClick={() => setSidebarOpen(true)}
              className="flex flex-col justify-center gap-1.5 w-10 h-10 border border-gray-250 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 rounded-xl px-2.5 hover:bg-primary-light hover:border-primary dark:hover:bg-primary/20 transition-all cursor-pointer"
              aria-label="Toggle Menu"
            >
              <span className="block h-0.5 w-full bg-gray-800 dark:bg-white rounded" />
              <span className="block h-0.5 w-full bg-gray-800 dark:bg-white rounded" />
              <span className="block h-0.5 w-full bg-gray-800 dark:bg-white rounded" />
            </button>

            {/* Logo */}
            <div className="flex items-center gap-3">
              <a href="#" className="flex items-center gap-0.5 font-heading font-black text-2xl tracking-tighter text-primary dark:text-blue-400">
                <span>Rek'ANY</span>
                <span className="text-accent animate-pulse">.</span>
                <span className="text-gray-800 dark:text-white">MG</span>
              </a>

              {/* STUNNING LANG SELECTOR IMMEDIATELY TO THE RIGHT OF THE LOGO! */}
              <div className="relative">
                <button
                  onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                  className="flex items-center gap-1 px-3 py-1.5 border border-gray-200 dark:border-gray-800 hover:border-primary bg-gray-50/50 dark:bg-gray-800/50 hover:bg-white dark:hover:bg-gray-800 rounded-full text-xs font-bold text-gray-700 dark:text-gray-300 transition-all duration-200 cursor-pointer shadow-sm select-none"
                >
                  <span>{currentLangLabel[lang].flag}</span>
                  <span className="hidden sm:inline">{currentLangLabel[lang].label}</span>
                  <span className="sm:hidden">{currentLangLabel[lang].code}</span>
                  <span className="text-[10px] text-gray-400">▼</span>
                </button>
                {langDropdownOpen && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setLangDropdownOpen(false)} />
                    <div className="absolute top-full left-0 mt-1 z-50 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-xl min-w-[130px] py-1 animate-fadeIn">
                      {(['fr', 'mg', 'en'] as Language[]).map((l) => (
                        <div
                          key={l}
                          onClick={() => {
                            setLang(l);
                            setLangDropdownOpen(false);
                          }}
                          className={`flex items-center gap-2 px-3 py-2 text-xs font-semibold cursor-pointer hover:bg-primary-light dark:hover:bg-blue-900/35 hover:text-primary dark:hover:text-blue-400 transition-colors ${
                            lang === l ? 'text-primary dark:text-blue-400 font-bold bg-primary-light/50 dark:bg-blue-900/20' : 'text-gray-700 dark:text-gray-300'
                          }`}
                        >
                          <span>{currentLangLabel[l].flag}</span>
                          <span>{currentLangLabel[l].label}</span>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Nav Search input - desktop */}
          <div className="hidden lg:flex flex-1 max-w-xs relative items-center">
            <span className="absolute left-3.5 text-gray-400 pointer-events-none text-xs">🔍</span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.search_placeholder}
              className="w-full pl-9 pr-4 py-2 border border-gray-250 dark:border-gray-700 bg-gray-50 dark:bg-gray-850 text-gray-800 dark:text-white rounded-full text-xs focus:outline-none focus:border-primary focus:bg-white focus:shadow-sm transition-all"
            />
          </div>

          {/* Right navbar elements */}
          <div className="flex items-center gap-3">
            <ul className="hidden md:flex items-center gap-5 nav-links text-sm font-semibold select-none">
              <li>
                <button
                  onClick={() => handleNavClick('courses')}
                  className="text-gray-500 hover:text-primary dark:text-gray-400 dark:hover:text-blue-400 transition-colors cursor-pointer"
                >
                  {t.nav_courses}
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('features')}
                  className="text-gray-500 hover:text-primary dark:text-gray-400 dark:hover:text-blue-400 transition-colors cursor-pointer"
                >
                  {t.nav_why}
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('pricing')}
                  className="text-gray-500 hover:text-primary dark:text-gray-400 dark:hover:text-blue-400 transition-colors cursor-pointer"
                >
                  {t.nav_pricing}
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('faq')}
                  className="text-gray-500 hover:text-primary dark:text-gray-400 dark:hover:text-blue-400 transition-colors cursor-pointer"
                >
                  FAQ
                </button>
              </li>
            </ul>

            {/* Theme Toggle Button */}
            <button
              onClick={toggleTheme}
              className="flex w-9 h-9 items-center justify-center bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-full hover:border-primary text-gray-500 dark:text-gray-300 transition-colors cursor-pointer"
              title={t.dark_mode}
            >
              {theme === 'dark' ? '☀️' : '🌙'}
            </button>
          </div>
        </div>
      </nav>
    </>
  );
}
