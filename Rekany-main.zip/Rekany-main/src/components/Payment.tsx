import React from 'react';
import { TRANSLATIONS } from '../data';
import { Language } from '../types';

interface PaymentProps {
  lang: Language;
  openEnrollModal: (courseName?: string) => void;
}

export default function Payment({ lang, openEnrollModal }: PaymentProps) {
  const t = TRANSLATIONS[lang];

  return (
    <section id="payment" className="py-16 md:py-20 bg-gray-50 dark:bg-gray-900 scroll-mt-10">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Section Heading */}
        <div className="text-center space-y-3 mb-12 max-w-xl md:max-w-3xl mx-auto">
          <div className="text-xs uppercase font-extrabold tracking-widest text-primary dark:text-blue-400">
            {t.section_pay_label}
          </div>
          <h2 className="font-heading font-bold text-2.5xl sm:text-3.5xl text-gray-900 dark:text-white leading-tight">
            {t.section_pay_title}
          </h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm sm:text-base leading-relaxed">
            {t.section_pay_sub}
          </p>
        </div>

        {/* MVola Interactive Informational Panel */}
        <div className="max-w-xl mx-auto bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700/80 rounded-3xl p-6 sm:p-10 shadow-sm select-text">
          <div className="flex items-center gap-4 pb-6 border-b border-gray-150 dark:border-gray-700 mb-8 select-none">
            <div className="w-14 h-14 bg-[#E60026] text-white font-heading font-black text-xs tracking-tighter flex flex-col items-center justify-center rounded-2xl shadow-md rotate-[-3deg]">
              <span>MVOLA</span>
            </div>
            <div>
              <h3 className="font-heading font-extrabold text-base sm:text-lg text-gray-900 dark:text-white">
                {t.mvola_title}
              </h3>
              <p className="text-xs text-gray-400 dark:text-gray-500 font-bold uppercase tracking-wider">
                {t.mvola_sub}
              </p>
            </div>
          </div>

          {/* Core Interactive Steps List */}
          <div className="space-y-6 select-text">
            
            {/* Step 1 */}
            <div className="flex gap-4 items-start">
              <div className="w-8 h-8 rounded-full bg-primary text-white font-heading text-xs font-black flex items-center justify-center shrink-0 shadow-sm select-none">
                1
              </div>
              <div className="space-y-1">
                <h4 className="font-heading font-bold text-xs sm:text-sm text-gray-900 dark:text-white">
                  {t.step1_title}
                </h4>
                <p className="text-gray-500 dark:text-gray-400 text-xs sm:text-sm font-medium leading-relaxed">
                  {t.step1_desc}
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex gap-4 items-start">
              <div className="w-8 h-8 rounded-full bg-primary text-white font-heading text-xs font-black flex items-center justify-center shrink-0 shadow-sm select-none">
                2
              </div>
              <div className="space-y-1">
                <h4 className="font-heading font-bold text-xs sm:text-sm text-gray-900 dark:text-white">
                  {lang === 'fr' 
                    ? "Envoyez les frais de cours par MVola" 
                    : lang === 'mg'
                    ? "Alefaso amin'ny MVola ny sarany"
                    : "Send course payment via MVola"
                  }
                </h4>
                <p className="text-gray-500 dark:text-gray-400 text-xs sm:text-sm font-medium leading-relaxed">
                  {lang === 'fr' ? (
                    <>
                      Ouvrez votre application MVola, puis effectuez un transfert d'un montant de <span className="bg-primary-light text-primary dark:text-blue-300 font-bold px-1.5 py-0.5 rounded leading-none text-xs">50 000 Ar</span> vers le numéro sécurisé <span className="bg-primary-light text-primary dark:text-blue-300 font-bold px-1.5 py-0.5 rounded leading-none text-xs">034 56 897 87</span>. Conservez précieusement le reçu.
                    </>
                  ) : lang === 'mg' ? (
                    <>
                      Sokafy ny fampiharana MVola, dia alefaso ny sarany <span className="bg-primary-light text-primary dark:text-blue-300 font-bold px-1.5 py-0.5 rounded leading-none text-xs">50 000 Ar</span> any amin'ny laharana <span className="bg-primary-light text-primary dark:text-blue-300 font-bold px-1.5 py-0.5 rounded leading-none text-xs">034 56 897 87</span>. Tehirizo ny tapakila fandoavana.
                    </>
                  ) : (
                    <>
                      Launch your MVola payment application, send <span className="bg-primary-light text-primary dark:text-blue-300 font-bold px-1.5 py-0.5 rounded leading-none text-xs">50,000 Ar</span> to the standard enrollment number <span className="bg-primary-light text-primary dark:text-blue-300 font-bold px-1.5 py-0.5 rounded leading-none text-xs">034 56 897 87</span>. Secure your payment ID receipt.
                    </>
                  )}
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex gap-4 items-start">
              <div className="w-8 h-8 rounded-full bg-primary text-white font-heading text-xs font-black flex items-center justify-center shrink-0 shadow-sm select-none">
                3
              </div>
              <div className="space-y-1">
                <h4 className="font-heading font-bold text-xs sm:text-sm text-gray-900 dark:text-white">
                  {t.step3_title}
                </h4>
                <p className="text-gray-500 dark:text-gray-400 text-xs sm:text-sm font-medium leading-relaxed">
                  {t.step3_desc}
                </p>
              </div>
            </div>

          </div>

          {/* Payment Warning Warning Badge */}
          <div className="mt-8 p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 text-xs text-amber-800 dark:text-amber-400 select-text flex items-start gap-3">
            <span className="text-base select-none">⚠️</span>
            <div className="leading-relaxed font-medium">
              {t.pay_note}
            </div>
          </div>

          {/* Confirm Button Trigger */}
          <div className="mt-8">
            <button
              onClick={() => openEnrollModal()}
              className="w-full py-4 bg-primary dark:bg-blue-600 text-white font-extrabold text-sm rounded-xl tracking-wider hover:bg-primary-dark transition-all shadow-lg shadow-blue-500/10 select-none border-none cursor-pointer"
            >
              {t.confirm_pay}
            </button>
          </div>

        </div>

      </div>
    </section>
  );
}
