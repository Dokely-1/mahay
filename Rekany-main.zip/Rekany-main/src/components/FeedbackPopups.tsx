import React, { useState, useEffect, useRef } from 'react';
import { TRANSLATIONS } from '../data';
import { Language } from '../types';

interface FeedbackPopupsProps {
  lang: Language;
  scrollToSection: (id: string) => void;
}

export default function FeedbackPopups({ lang, scrollToSection }: FeedbackPopupsProps) {
  const t = TRANSLATIONS[lang];

  // Back to top visible state tracker
  const [backTopVisible, setBackTopVisible] = useState(false);

  // Social proof states
  const [socialProofOpen, setSocialProofOpen] = useState(false);
  const [socialProofName, setSocialProofName] = useState('Rakoto');
  const [socialProofCourse, setSocialProofCourse] = useState('Marketing Digital');

  // Exit intent popup state
  const [exitPopupOpen, setExitPopupOpen] = useState(false);
  const [exitShown, setExitShown] = useState(false);

  // Dynamic toast state
  const [toastMessage, setToastMessage] = useState('');
  const [toastVisible, setToastVisible] = useState(false);

  // Lists for social proof names
  const spNames = ['Rakoto', 'Fanja', 'Hery', 'Miora', 'Tsiky', 'Valérie', 'Jean-Paul', 'Andry', 'Noro', 'Solo', 'Ando', 'Tina', 'Rija'];
  const spCourses = [
    'Marketing Digital',
    'Développement Web',
    'Bureautique Avancée',
    'Maintenance Réseau',
    'Accès Complet',
    'Maintenance Informatique',
    'Booster Page de Vente'
  ];

  // Watch scroll positions
  useEffect(() => {
    const handleScroll = () => {
      setBackTopVisible(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Global toast listener trigger helper channel
  useEffect(() => {
    const handleToastEvent = (e: Event) => {
      const customEvent = e as CustomEvent<string>;
      if (customEvent.detail) {
        setToastMessage(customEvent.detail);
        setToastVisible(true);
      }
    };

    window.addEventListener('rekany-toast', handleToastEvent);
    return () => window.removeEventListener('rekany-toast', handleToastEvent);
  }, []);

  // Timer loop for auto-closing local toast alerts
  useEffect(() => {
    if (!toastVisible) return;
    const timer = setTimeout(() => {
      setToastVisible(false);
    }, 3200);
    return () => clearTimeout(timer);
  }, [toastVisible]);

  // Social Proof triggers schedule loop
  useEffect(() => {
    const triggerProof = () => {
      const rName = spNames[Math.floor(Math.random() * spNames.length)];
      const rCourse = spCourses[Math.floor(Math.random() * spCourses.length)];
      setSocialProofName(rName);
      setSocialProofCourse(rCourse);
      setSocialProofOpen(true);

      // Slide out after 5.5s
      setTimeout(() => {
        setSocialProofOpen(false);
      }, 5500);
    };

    // First trigger after 12 seconds
    const firstTimeout = setTimeout(triggerProof, 12000);

    // Following intervals every 35 seconds
    const interval = setInterval(triggerProof, 35000);

    return () => {
      clearTimeout(firstTimeout);
      clearInterval(interval);
    };
  }, []);

  // Exit intent triggers (desktop mouse and mobile inactivity)
  useEffect(() => {
    // Mouse leave event
    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY < 10 && !exitShown) {
        setExitShown(true);
        setExitPopupOpen(true);
      }
    };

    document.addEventListener('mouseleave', handleMouseLeave);

    // Mobile inactive observer (triggers after 45s of user inactivity)
    let inactivityTimer = setTimeout(() => {
      if (!exitShown) {
        setExitShown(true);
        setExitPopupOpen(true);
      }
    }, 45000);

    const resetInactivity = () => {
      if (exitShown) return;
      clearTimeout(inactivityTimer);
      inactivityTimer = setTimeout(() => {
        if (!exitShown) {
          setExitShown(true);
          setExitPopupOpen(true);
        }
      }, 45000);
    };

    document.addEventListener('touchstart', resetInactivity);
    document.addEventListener('click', resetInactivity);

    return () => {
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('touchstart', resetInactivity);
      document.removeEventListener('click', resetInactivity);
      clearTimeout(inactivityTimer);
    };
  }, [exitShown]);

  return (
    <>
      {/* 1. WHATSAPP FLOATING BUBBLE */}
      <a
        href="https://wa.me/261345689787?text=Bonjour%20Rek'ANY!%20Je%20veux%20m'inscrire%20à%20une%20formation."
        className="fixed bottom-6 right-6 z-40 bg-[#25D366] text-white rounded-full p-4 flex items-center gap-2 shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all group overflow-hidden max-w-[56px] hover:max-w-[240px] select-none"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Contacter sur WhatsApp"
      >
        <svg viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
        </svg>
        <span className="font-heading font-black text-xs uppercase tracking-wider whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          Aide via WhatsApp
        </span>
      </a>

      {/* 2. BACK TO TOP BUTTON */}
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className={`fixed bottom-[90px] right-6 z-40 w-11 h-11 bg-primary text-white border-none rounded-full flex items-center justify-center font-bold shadow-lg hover:shadow-xl hover:scale-105 transition-all select-none cursor-pointer ${
          backTopVisible ? 'opacity-100 scale-100 pointer-events-auto' : 'opacity-0 scale-50 pointer-events-none'
        }`}
        aria-label="Retourner en haut"
      >
        ▲
      </button>

      {/* 3. SOCIAL PROOF NOTIFICATION POPUP */}
      <div
        className={`fixed bottom-[150px] sm:bottom-6 left-6 z-40 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700/80 p-4 rounded-2xl shadow-xl flex items-center gap-3.5 max-w-[290px] transition-all duration-500 ease-out select-text ${
          socialProofOpen ? 'translate-x-0 scale-100 opacity-100' : '-translate-x-[360px] scale-90 opacity-0 pointer-events-none'
        }`}
      >
        <div className="w-10 h-10 rounded-full bg-primary/10 text-primary dark:text-blue-400 text-xl flex items-center justify-center shrink-0 select-none">
          🎓
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs text-gray-500 dark:text-gray-300 font-medium leading-tight">
            <span className="font-bold text-gray-900 dark:text-white">{socialProofName}</span>{' '}
            {lang === 'fr' 
              ? "vient de s'inscrire à" 
              : lang === 'mg'
              ? "vao avy nisoratra anarana tamin'ny"
              : "just enrolled in"
            }{' '}
            <span className="text-primary dark:text-blue-400 font-bold">{socialProofCourse}</span>
          </p>
        </div>
        <button
          onClick={() => setSocialProofOpen(false)}
          className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 text-xs font-bold font-sans cursor-pointer select-none bg-transparent border-none shrink-0"
        >
          ✕
        </button>
      </div>

      {/* 4. EXIT INTENT EMERGENCY POPUP OVERLAY */}
      {exitPopupOpen && (
        <div className="fixed inset-0 z-200 flex items-center justify-center bg-black/75 backdrop-blur-[4px] p-4 select-text">
          <div className="fixed inset-0" onClick={() => setExitPopupOpen(false)} />
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 sm:p-10 max-w-md w-full text-center relative z-210 shadow-2xl animate-fadeIn animate-duration-300 select-text">
            
            {/* Close */}
            <button
              onClick={() => setExitPopupOpen(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 text-lg font-bold font-sans cursor-pointer select-none bg-transparent border-none"
            >
              ✕
            </button>

            <div className="text-5xl mb-4 select-none">🎓</div>
            
            <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-amber-100 text-amber-800 font-heading text-[10px] font-extrabold uppercase tracking-wide mb-4 select-none">
              ⏰ {lang === 'fr' ? "Aujourd'hui seulement" : "Androany ihany"}
            </div>

            <h3 className="font-heading font-black text-xl sm:text-2xl text-gray-950 dark:text-white mb-2 leading-tight">
              {lang === 'fr' ? (
                <>Attendez ! Votre <span className="text-primary dark:text-blue-400">formation</span> vous attend</>
              ) : lang === 'mg' ? (
                <>Andraso kely ! Ny <span className="text-primary dark:text-blue-400">fiofananao</span> efa vonona</>
              ) : (
                <>Wait! Your <span className="text-primary dark:text-blue-400">training</span> is waiting</>
              )}
            </h3>

            <p className="text-gray-500 dark:text-gray-400 text-xs sm:text-sm font-medium leading-relaxed mb-8">
              {lang === 'fr'
                ? "Ne partez pas sans profiter de l'accès à vie. Plus de 500 Malgaches ont déjà transformé leur carrière avec Rek'ANY."
                : lang === 'mg'
                ? "Aza mandao fotsiny raha tsy mahazo ny fidirana mandrakizay. Maherin'ny 500 Malagasy no nanova ny fiainany tamin'ny Rek'ANY."
                : "Don't leave without securing lifetime access. Join over 500 Malagasy people who transformed their skills with Rek'ANY."
              }
            </p>

            {/* Modal actions */}
            <div className="space-y-3 select-none">
              <button
                onClick={() => {
                  setExitPopupOpen(false);
                  scrollToSection('courses');
                }}
                className="w-full py-3.5 bg-primary dark:bg-blue-600 text-white font-extrabold text-sm rounded-xl tracking-wider hover:bg-primary-dark shadow-lg shadow-blue-500/10 transition-all border-none cursor-pointer"
              >
                🚀 {lang === 'fr' ? "Voir les formations → 50 000 Ar" : "Andeha hijery ny fiofanana"}
              </button>
              <button
                onClick={() => setExitPopupOpen(false)}
                className="w-full py-2 bg-transparent text-gray-400 hover:text-gray-500 dark:hover:text-gray-300 font-bold text-xs uppercase tracking-wide transition-colors border-none cursor-pointer"
              >
                {lang === 'fr' ? "Non merci, je ne veux pas progresser" : "Tsia, misaotra betsaka"}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* 5. GLOBAL BOTTOM DYNAMIC TOAST */}
      <div
        className={`fixed bottom-20 left-1/2 -translate-x-1/2 z-200 bg-gray-950/95 text-white font-semibold text-xs sm:text-sm py-3 px-6 rounded-full shadow-2xl border border-white/5 transition-all duration-300 max-w-[90vw] text-center select-text ${
          toastVisible ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-4 scale-95 pointer-events-none'
        }`}
      >
        {toastMessage}
      </div>
    </>
  );
}
