import React, { useState, useEffect, useRef } from 'react';
import { TESTIMONIALS, TRANSLATIONS } from '../data';
import { Language } from '../types';

interface TestimonialsProps {
  lang: Language;
}

export default function Testimonials({ lang }: TestimonialsProps) {
  const t = TRANSLATIONS[lang];
  
  // Custom states for counters
  const [students, setStudents] = useState(0);
  const [certs, setCerts] = useState(0);
  const [courses, setCourses] = useState(0);

  const containerRef = useRef<HTMLDivElement>(null);
  const [hasAnimated, setHasAnimated] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting && !hasAnimated) {
          setHasAnimated(true);
        }
      },
      { threshold: 0.2 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => {
      if (containerRef.current) {
        observer.unobserve(containerRef.current);
      }
    };
  }, [hasAnimated]);

  useEffect(() => {
    if (!hasAnimated) return;

    // Fast counters animation
    let start = 0;
    const duration = 1500; // 1.5s
    const stepTime = 30; // 30ms step
    const steps = duration / stepTime;
    
    let currentStep = 0;

    const interval = setInterval(() => {
      currentStep++;
      const progress = currentStep / steps;
      // cubic ease-out
      const easedProgress = 1 - Math.pow(1 - progress, 3);

      setStudents(Math.floor(easedProgress * 500));
      setCerts(Math.floor(easedProgress * 480));
      setCourses(Math.floor(easedProgress * 6));

      if (currentStep >= steps) {
        setStudents(500);
        setCerts(480);
        setCourses(6);
        clearInterval(interval);
      }
    }, stepTime);

    return () => clearInterval(interval);
  }, [hasAnimated]);

  return (
    <section id="temoignages" className="py-16 md:py-20 bg-gray-50 dark:bg-gray-900 scroll-mt-10">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Section Heading */}
        <div className="text-center space-y-3 mb-12 max-w-xl md:max-w-3xl mx-auto">
          <div className="text-xs uppercase font-extrabold tracking-widest text-primary dark:text-blue-400">
            ⭐ {lang === 'fr' ? 'Témoignages' : lang === 'mg' ? 'Tombotsoa' : 'Testimonials'}
          </div>
          <h2 className="font-heading font-bold text-2.5xl sm:text-3.5xl text-gray-900 dark:text-white leading-tight">
            {lang === 'fr' ? 'Ce que disent nos étudiants' : lang === 'mg' ? 'Inona no lazain\'ireo mpianatray' : 'What our students are saying'}
          </h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm sm:text-base leading-relaxed">
            {lang === 'fr' 
              ? "Plus de 500 apprenants ont déjà transformé leur carrière grâce à Rek'ANY.MG."
              : lang === 'mg'
              ? "Mpanaraka fiofanana maherin'ny 500 no efa nanova ny fiainany arak'asa tamin'ny alalan'ny Rek'ANY.MG."
              : "Over 500 students have upgraded their careers leveraging Rek'ANY.MG courses."
            }
          </p>
        </div>

        {/* Testimonial Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {TESTIMONIALS.map((tItem, idx) => (
            <div
              key={idx}
              className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700/80 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between select-text"
            >
              <div>
                <div className="flex gap-0.5 text-amber-500 text-sm mb-3 select-none">
                  {Array.from({ length: tItem.stars }).map((_, sIdx) => '⭐')}
                </div>
                <p className="text-gray-600 dark:text-gray-300 text-xs sm:text-sm font-medium leading-relaxed italic mb-5">
                  {tItem.text}
                </p>
              </div>

              <div className="flex items-center gap-3 pt-4 border-t border-gray-100 dark:border-gray-700">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs text-white uppercase select-none"
                  style={{ background: tItem.color }}
                >
                  {tItem.avatar}
                </div>
                <div>
                  <div className="text-xs sm:text-sm font-bold text-gray-900 dark:text-white leading-snug">
                    {tItem.name}
                  </div>
                  <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mt-0.5 select-none">
                    {tItem.course}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Dynamic Animated Statistics Box */}
        <div
          ref={containerRef}
          className="grid grid-cols-2 sm:grid-cols-4 gap-6 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700/85 p-6 md:p-8 rounded-2xl shadow-sm text-center select-none"
        >
          <div className="space-y-1">
            <div className="font-heading font-black text-2.5xl sm:text-3.5xl text-primary dark:text-blue-400">
              {students}+
            </div>
            <div className="text-xs font-bold text-gray-500 dark:text-gray-400">
              {lang === 'fr' ? 'Étudiants formés' : lang === 'mg' ? 'Mpianatra nahavita' : 'Students trained'}
            </div>
          </div>

          <div className="space-y-1">
            <div className="font-heading font-black text-2.5xl sm:text-3.5xl text-primary dark:text-blue-400">
              {certs}+
            </div>
            <div className="text-xs font-bold text-gray-500 dark:text-gray-400">
              {lang === 'fr' ? 'Certificats délivrés' : lang === 'mg' ? 'Taratasy natolotra' : 'Certificates issued'}
            </div>
          </div>

          <div className="space-y-1">
            <div className="font-heading font-black text-2.5xl sm:text-3.5xl text-primary dark:text-blue-400">
              {courses}
            </div>
            <div className="text-xs font-bold text-gray-500 dark:text-gray-400">
              {t.stat_formations}
            </div>
          </div>

          <div className="space-y-1">
            <div className="font-heading font-black text-2.5xl sm:text-3.5xl text-primary dark:text-blue-400">
              4.8<span className="text-base text-gray-400">/5</span>
            </div>
            <div className="text-xs font-bold text-gray-500 dark:text-gray-400">
              {lang === 'fr' ? 'Note moyenne' : lang === 'mg' ? 'Naoty salan\'isa' : 'Average rating'}
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
