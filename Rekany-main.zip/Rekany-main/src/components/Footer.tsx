import React from 'react';
import { TRANSLATIONS } from '../data';
import { Language } from '../types';

interface FooterProps {
  lang: Language;
  scrollToSection: (id: string) => void;
  openEnrollModal: (courseName?: string) => void;
}

export default function Footer({ lang, scrollToSection, openEnrollModal }: FooterProps) {
  const t = TRANSLATIONS[lang];

  return (
    <footer className="bg-gray-950 text-gray-400 py-16 px-6 md:px-8 border-t border-gray-900 select-text">
      <div className="max-w-7xl mx-auto space-y-12">
        
        {/* Main Grid Content */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-12">
          
          {/* Col 1: Branding and description */}
          <div className="lg:col-span-4 space-y-4">
            <a href="#" className="inline-flex gap-0.5 font-heading font-black text-2xl text-white tracking-tighter select-none">
              <span>Rek'ANY</span>
              <span className="text-accent">.</span>
              <span>MG</span>
            </a>
            <p className="text-xs leading-relaxed max-w-sm text-gray-400 font-medium">
              {t.footer_desc}
            </p>
            <p className="text-[10px] text-gray-500 max-w-sm leading-relaxed leading-[14px]">
              Formation informatique à Madagascar · Formation Excel Madagascar · Formation marketing digital Madagascar · Cours développement web Antananarivo
            </p>
          </div>

          {/* Col 2: Courses list links */}
          <div className="lg:col-span-2.5 space-y-4 select-none">
            <div className="text-white text-xs font-bold uppercase tracking-wider">
              {t.footer_courses}
            </div>
            <ul className="space-y-2 text-xs font-semibold">
              <li>
                <button onClick={() => openEnrollModal(t.c1_title)} className="hover:text-white transition-colors cursor-pointer border-none bg-transparent">
                  {t.c1_title}
                </button>
              </li>
              <li>
                <button onClick={() => openEnrollModal(t.c2_title)} className="hover:text-white transition-colors cursor-pointer border-none bg-transparent">
                  {t.c2_title}
                </button>
              </li>
              <li>
                <button onClick={() => openEnrollModal(t.c3_title)} className="hover:text-white transition-colors cursor-pointer border-none bg-transparent">
                  {t.c3_title}
                </button>
              </li>
              <li>
                <button onClick={() => openEnrollModal(t.c4_title)} className="hover:text-white transition-colors cursor-pointer border-none bg-transparent">
                  {t.c4_title}
                </button>
              </li>
              <li>
                <button onClick={() => openEnrollModal(t.c5_title)} className="hover:text-white transition-colors cursor-pointer border-none bg-transparent">
                  {t.c5_title}
                </button>
              </li>
              <li>
                <button onClick={() => openEnrollModal(t.c6_title)} className="hover:text-white transition-colors cursor-pointer border-none bg-transparent">
                  {t.c6_title}
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Platform links */}
          <div className="lg:col-span-2.5 space-y-4 select-none">
            <div className="text-white text-xs font-bold uppercase tracking-wider">
              {t.footer_platform}
            </div>
            <ul className="space-y-2 text-xs font-semibold">
              <li>
                <button onClick={() => scrollToSection('courses')} className="hover:text-white transition-colors cursor-pointer border-none bg-transparent">
                  {t.footer_how}
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('pricing')} className="hover:text-white transition-colors cursor-pointer border-none bg-transparent">
                  {t.nav_pricing}
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('payment')} className="hover:text-white transition-colors cursor-pointer border-none bg-transparent">
                  {t.nav_payment}
                </button>
              </li>
              <li>
                <a href="#features" className="hover:text-white transition-colors">
                  {t.footer_cert}
                </a>
              </li>
              <li>
                <button onClick={() => scrollToSection('faq')} className="hover:text-white transition-colors cursor-pointer border-none bg-transparent">
                  FAQ
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Contacts details */}
          <div className="lg:col-span-3 space-y-4">
            <div className="text-white text-xs font-bold uppercase tracking-wider">
              Contact
            </div>
            <ul className="space-y-2.5 text-xs font-semibold">
              <li>
                <a
                  href="https://wa.me/261345689787?text=Bonjour%20Rek'ANY!%20Je%20veux%20m'inscrire%20à%20une%20formation."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white flex items-center gap-1.5"
                >
                  🟢 WhatsApp: 034 56 897 87
                </a>
              </li>
              <li className="text-gray-400">
                📬 {t.footer_email} : info@rekany.mg
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  🌐 Facebook / RekANY
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  ⚖️ {t.footer_legal}
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom copyright details */}
        <div className="pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-semibold select-none text-center sm:text-left text-gray-500">
          <div>
            © 2024–2026 <span className="text-white">Rek'ANY.MG</span> — {t.footer_rights}
          </div>
          <div className="text-accent flex items-center gap-1">
            <span>{t.footer_made}</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
