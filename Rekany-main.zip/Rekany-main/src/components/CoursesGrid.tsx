import React, { useState } from 'react';
import { TRANSLATIONS } from '../data';
import { Language } from '../types';

interface CoursesGridProps {
  lang: Language;
  searchQuery: string;
  openEnrollModal: (courseName?: string) => void;
}

interface CourseCardProps {
  key?: string;
  id: string;
  category: string;
  thumbEmoji: string;
  bgColor: string;
  badge?: string;
  badgeBg?: string;
  categoryLabel: string;
  categoryColor: string;
  title: string;
  desc: string;
  videosCount: number;
  rating: number;
  price: string;
  onEnroll: () => void;
  lang: Language;
}

function CourseCard({
  category,
  thumbEmoji,
  bgColor,
  badge,
  badgeBg,
  categoryLabel,
  categoryColor,
  title,
  desc,
  videosCount,
  rating,
  price,
  onEnroll,
  lang
}: CourseCardProps) {
  const t = TRANSLATIONS[lang];

  return (
    <div
      onClick={onEnroll}
      className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700/80 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer flex flex-col group select-text"
    >
      {/* Thumbnail area */}
      <div className={`h-40 flex items-center justify-center text-5xl relative transition-transform group-hover:scale-103 duration-300 ${bgColor}`}>
        <span>{thumbEmoji}</span>
        {badge && (
          <span className={`absolute top-3.5 right-3.5 text-[9.5px] uppercase font-black tracking-wider py-1 px-3.5 rounded-full shadow-sm text-white ${badgeBg || 'bg-primary'}`}>
            {badge}
          </span>
        )}
      </div>

      {/* Body content */}
      <div className="p-5 flex-1 flex flex-col">
        <div className="font-heading text-[10px] uppercase font-bold tracking-widest mb-1.5" style={{ color: categoryColor }}>
          {categoryLabel}
        </div>
        <h3 className="font-heading font-bold text-base sm:text-lg text-gray-900 dark:text-white mb-2 leading-snug group-hover:text-primary dark:group-hover:text-blue-400 transition-colors">
          {title}
        </h3>
        <p className="text-gray-500 dark:text-gray-400 text-xs sm:text-sm line-clamp-3 leading-relaxed mb-4 flex-1">
          {desc}
        </p>

        {/* Course metadata values */}
        <div className="flex items-center gap-4 text-[11px] font-semibold text-gray-400 dark:text-gray-500 mb-4 select-none">
          <span className="flex items-center gap-1.5">🎬 {videosCount} {t.videos}</span>
          <span className="flex items-center gap-1.5">📄 PDF</span>
          <span className="flex items-center gap-1.5">⭐ {rating}</span>
        </div>

        {/* Footer actions */}
        <div className="pt-4 border-t border-gray-150 dark:border-gray-700 flex items-center justify-between gap-2">
          <div className="select-none">
            <div className="font-heading font-black text-base sm:text-lg text-gray-900 dark:text-white leading-tight">
              {price}
            </div>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest -mt-0.5 block">
              {t.lifetime}
            </span>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEnroll();
            }}
            className="px-5 py-2.5 bg-primary dark:bg-blue-600 text-white rounded-xl text-xs font-extrabold hover:bg-primary-dark transition-colors cursor-pointer select-none border-none"
          >
            {t.enroll}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function CoursesGrid({ lang, searchQuery, openEnrollModal }: CoursesGridProps) {
  const t = TRANSLATIONS[lang];
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filterTabs = [
    { id: 'all', label: t.filter_all },
    { id: 'marketing', label: t.filter_marketing },
    { id: 'digital', label: t.filter_digital },
    { id: 'reseau', label: t.filter_reseau },
    { id: 'info', label: t.filter_info },
    { id: 'dev', label: t.filter_dev },
    { id: 'bureau', label: t.filter_bureau },
  ];

  const coursesList = [
    {
      id: 'marketing',
      category: 'marketing',
      thumbEmoji: '🚀',
      bgColor: 'bg-amber-50 dark:bg-amber-950/20',
      badge: t.badge_bestseller,
      badgeBg: 'bg-amber-600',
      categoryLabel: t.cat_marketing,
      categoryColor: '#D97706',
      title: t.c1_title,
      desc: t.c1_desc,
      videosCount: 24,
      rating: 4.9,
      price: '50 000 Ar'
    },
    {
      id: 'digital',
      category: 'digital',
      thumbEmoji: '📱',
      bgColor: 'bg-blue-50 dark:bg-blue-950/20',
      categoryLabel: t.cat_digital,
      categoryColor: '#1B4FD8',
      title: t.c2_title,
      desc: t.c2_desc,
      videosCount: 30,
      rating: 4.8,
      price: '50 000 Ar'
    },
    {
      id: 'reseau',
      category: 'reseau',
      thumbEmoji: '🌐',
      bgColor: 'bg-emerald-50 dark:bg-emerald-950/20',
      categoryLabel: t.cat_reseau,
      categoryColor: '#059669',
      title: t.c3_title,
      desc: t.c3_desc,
      videosCount: 28,
      rating: 4.7,
      price: '50 000 Ar'
    },
    {
      id: 'info',
      category: 'info',
      thumbEmoji: '💻',
      bgColor: 'bg-rose-50 dark:bg-rose-950/20',
      categoryLabel: t.cat_info,
      categoryColor: '#DC2626',
      title: t.c4_title,
      desc: t.c4_desc,
      videosCount: 26,
      rating: 4.8,
      price: '50 000 Ar'
    },
    {
      id: 'dev',
      category: 'dev',
      thumbEmoji: '⌨️',
      bgColor: 'bg-purple-50 dark:bg-purple-950/20',
      badge: t.badge_popular,
      badgeBg: 'bg-purple-600',
      categoryLabel: t.cat_dev,
      categoryColor: '#7C3AED',
      title: t.c5_title,
      desc: t.c5_desc,
      videosCount: 45,
      rating: 4.9,
      price: '50 000 Ar'
    },
    {
      id: 'bureau',
      category: 'bureau',
      thumbEmoji: '📊',
      bgColor: 'bg-sky-50 dark:bg-sky-950/20',
      categoryLabel: t.cat_bureau,
      categoryColor: '#0284C7',
      title: t.c6_title,
      desc: t.c6_desc,
      videosCount: 22,
      rating: 4.7,
      price: '50 000 Ar'
    }
  ];

  // Apply search query first and then category filter
  const filteredCourses = coursesList.filter(course => {
    const matchesSearch = !searchQuery ||
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.desc.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.categoryLabel.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = selectedCategory === 'all' || course.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  return (
    <section id="courses" className="py-16 md:py-20 bg-gray-50 dark:bg-gray-900 scroll-mt-10">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Section Heading */}
        <div className="text-center md:text-left space-y-3 mb-10 max-w-xl md:max-w-3xl">
          <div className="text-xs uppercase font-extrabold tracking-widest text-primary dark:text-blue-400">
            {t.section_courses_label}
          </div>
          <h2 className="font-heading font-bold text-2.5xl sm:text-3.5xl text-gray-900 dark:text-white leading-tight">
            {t.section_courses_title}
          </h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm sm:text-base leading-relaxed">
            {t.section_courses_sub}
          </p>
        </div>

        {/* Filter Navigation Bar */}
        <div className="flex gap-2.5 overflow-x-auto pb-4 select-none scrollbar-none scroll-smooth">
          {filterTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedCategory(tab.id)}
              className={`px-4.5 py-2.5 rounded-xl border text-xs font-bold transition-all whitespace-nowrap cursor-pointer hover:border-primary shrink-0 ${
                selectedCategory === tab.id
                  ? 'bg-primary dark:bg-blue-600 border-primary text-white shadow-sm'
                  : 'bg-white dark:bg-gray-800 border-gray-250 dark:border-gray-700 text-gray-600 dark:text-gray-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Courses Cards Grid */}
        {filteredCourses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-4">
            {filteredCourses.map((course) => (
              <CourseCard
                key={course.id}
                id={course.id}
                category={course.category}
                thumbEmoji={course.thumbEmoji}
                bgColor={course.bgColor}
                badge={course.badge}
                badgeBg={course.badgeBg}
                categoryLabel={course.categoryLabel}
                categoryColor={course.categoryColor}
                title={course.title}
                desc={course.desc}
                videosCount={course.videosCount}
                rating={course.rating}
                price={course.price}
                onEnroll={() => openEnrollModal(course.title)}
                lang={lang}
              />
            ))}
          </div>
        ) : (
          <div className="py-20 text-center select-none bg-white dark:bg-gray-800 border border-gray-205 dark:border-gray-700 rounded-3xl mt-4">
            <div className="text-5xl mb-4 text-gray-300 dark:text-gray-600">🔍</div>
            <div className="font-heading font-bold text-gray-700 dark:text-gray-200 mb-1 lg:text-lg">
              {lang === 'fr' 
                ? "Aucun cours trouvé" 
                : lang === 'mg'
                ? "Tsy misy fianarana hita"
                : "No courses found"
              }
            </div>
            <p className="text-xs sm:text-sm text-gray-400 dark:text-gray-500">
              {lang === 'fr'
                ? `Essayez de modifier vos mots-clés de recherche ou changez la catégorie.`
                : lang === 'mg'
                ? "Andramo ovaina ny teny fikarohanao na ovay ny katesoria."
                : "Try adjusting your search terms or changing your category."
              }
            </p>
          </div>
        )}

      </div>
    </section>
  );
}
