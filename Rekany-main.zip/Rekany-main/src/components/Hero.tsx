import React from 'react';
import { TRANSLATIONS } from '../data';
import { Language } from '../types';

interface HeroProps {
  lang: Language;
  openEnrollModal: (courseName?: string) => void;
  scrollToSection: (id: string) => void;
}

export default function Hero({ lang, openEnrollModal, scrollToSection }: HeroProps) {
  const t = TRANSLATIONS[lang];

  const heroCourseLines = [
    { icon: '🚀', title: t.c1_title, price: '50 000 Ar', bgColor: 'bg-amber-100/70 dark:bg-amber-900/40 text-amber-600 dark:text-amber-400' },
    { icon: '📱', title: t.c2_title, price: '50 000 Ar', bgColor: 'bg-blue-100/70 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400' },
    { icon: '🌐', title: t.c3_title, price: '50 000 Ar', bgColor: 'bg-emerald-100/70 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400' },
    { icon: '💻', title: t.c4_title, price: '50 000 Ar', bgColor: 'bg-rose-100/70 dark:bg-rose-900/40 text-rose-600 dark:text-rose-400' },
    { icon: '⌨️', title: t.c5_title, price: '50 000 Ar', bgColor: 'bg-purple-100/70 dark:bg-purple-900/40 text-purple-600 dark:text-purple-400' },
    { icon: '📊', title: t.c6_title, price: '50 000 Ar', bgColor: 'bg-sky-100/70 dark:bg-sky-900/40 text-sky-600 dark:text-sky-400' },
  ];

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-white via-gray-50 to-white dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 text-gray-900 dark:text-white py-16 md:py-24 px-6 md:px-8 border-b border-gray-150 dark:border-gray-800">
      {/* Decorative vector elements */}
      <div className="absolute -top-48 -right-48 w-96 h-96 rounded-full bg-blue-500/5 pointer-events-none filter blur-3xl" />
      <div className="absolute -bottom-24 -left-24 w-80 h-80 rounded-full bg-primary/5 pointer-events-none filter blur-2xl" />

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center relative z-10">
        {/* Left main content */}
        <div className="lg:col-span-7 space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 dark:bg-blue-950/20 text-primary dark:text-blue-400 font-heading text-xs font-bold uppercase tracking-widest select-none italic">
            <span>✨</span>
            <span>{t.hero_badge}</span>
          </div>

          <h1
            className="font-heading font-black text-4xl sm:text-5xl lg:text-6xl text-gray-950 dark:text-white leading-[1.1] tracking-tighter select-text [&>strong]:text-primary [&>strong]:dark:text-blue-400 [&>strong]:font-black"
            dangerouslySetInnerHTML={{ __html: t.hero_title }}
          />

          <p className="text-gray-500 dark:text-gray-400 text-base md:text-lg max-w-xl font-normal leading-relaxed select-text">
            {t.hero_desc}
          </p>

          <div className="flex flex-col sm:flex-row gap-4 pt-2">
            <button
              onClick={() => scrollToSection('courses')}
              className="px-8 py-3.5 bg-primary dark:bg-blue-600 text-white rounded-xl text-sm font-extrabold shadow-lg shadow-blue-500/10 hover:bg-primary-dark hover:-translate-y-0.5 transition-all text-center select-none cursor-pointer border-none"
            >
              {t.hero_btn1}
            </button>
            <button
              onClick={() => openEnrollModal()}
              className="px-8 py-3.5 bg-white dark:bg-gray-800 border border-gray-250 dark:border-gray-700 text-gray-700 dark:text-gray-200 rounded-xl text-sm font-extrabold hover:bg-gray-50 dark:hover:bg-gray-750 transition-all text-center select-none cursor-pointer"
            >
              {t.hero_btn2}
            </button>
          </div>

          {/* Statistics grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 pt-6 border-t border-gray-150 dark:border-gray-850">
            <div className="space-y-1 select-none">
              <div className="font-heading text-2.5xl md:text-3.5xl font-black text-primary dark:text-blue-400">6</div>
              <div className="text-[10px] text-gray-450 dark:text-gray-500 uppercase font-extrabold tracking-widest">{t.stat_formations}</div>
            </div>
            <div className="space-y-1 select-none">
              <div className="font-heading text-2.5xl md:text-3.5xl font-black text-primary dark:text-blue-400">100%</div>
              <div className="text-[10px] text-gray-450 dark:text-gray-500 uppercase font-extrabold tracking-widest">{t.stat_online}</div>
            </div>
            <div className="space-y-1 select-none">
              <div className="font-heading text-2.5xl md:text-3.5xl font-black text-primary dark:text-blue-400">50K Ar</div>
              <div className="text-[10px] text-gray-450 dark:text-gray-500 uppercase font-extrabold tracking-widest">{t.stat_price}</div>
            </div>
            <div className="space-y-1 select-none">
              <div className="font-heading text-2.5xl md:text-3.5xl font-black text-primary dark:text-blue-400">∞</div>
              <div className="text-[10px] text-gray-450 dark:text-gray-500 uppercase font-extrabold tracking-widest">{t.stat_access}</div>
            </div>
          </div>
        </div>

        {/* Right card element */}
        <div className="lg:col-span-5 hidden lg:block">
          <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700/80 rounded-2xl p-6 shadow-xl shadow-gray-200/50 dark:shadow-black/20 space-y-4 select-none">
            <div className="font-heading font-black text-xs text-gray-950 dark:text-white pb-3 border-b border-gray-150 dark:border-gray-755 uppercase tracking-widest">
              {t.hero_card_title}
            </div>
            <div className="space-y-2.5">
              {heroCourseLines.map((line, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-xl bg-gray-50 dark:bg-gray-900/50 hover:bg-white dark:hover:bg-gray-750 border border-gray-150/70 dark:border-gray-755 hover:border-primary dark:hover:border-blue-400 transition-all duration-200 group cursor-pointer"
                  onClick={() => openEnrollModal(line.title)}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-bold text-base filter ${line.bgColor}`}>
                      {line.icon}
                    </div>
                    <span className="text-xs sm:text-sm font-bold text-gray-800 dark:text-gray-200 group-hover:text-primary dark:group-hover:text-blue-400 transition-colors">
                      {line.title}
                    </span>
                  </div>
                  <span className="text-[10px] sm:text-xs font-black text-primary dark:text-blue-400 bg-primary-light dark:bg-blue-950/20 py-1.5 px-3 rounded-full border border-primary/10 dark:border-blue-900/30">
                    {line.price}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
