import React from 'react';
import { TRANSLATIONS } from '../data';
import { Language } from '../types';

interface FeaturesProps {
  lang: Language;
}

export default function Features({ lang }: FeaturesProps) {
  const t = TRANSLATIONS[lang];

  const featuresList = [
    { icon: '🎬', title: t.feat1_title, desc: t.feat1_desc, bgColor: 'bg-blue-50 dark:bg-blue-900/10' },
    { icon: '📄', title: t.feat2_title, desc: t.feat2_desc, bgColor: 'bg-amber-50 dark:bg-amber-900/10' },
    { icon: '✅', title: t.feat3_title, desc: t.feat3_desc, bgColor: 'bg-emerald-50 dark:bg-emerald-900/10' },
    { icon: '🏆', title: t.feat4_title, desc: t.feat4_desc, bgColor: 'bg-rose-50 dark:bg-rose-900/10' },
    { icon: '📱', title: t.feat5_title, desc: t.feat5_desc, bgColor: 'bg-purple-50 dark:bg-purple-900/10' },
    { icon: '💬', title: t.feat6_title, desc: t.feat6_desc, bgColor: 'bg-sky-50 dark:bg-sky-900/10' },
  ];

  return (
    <section id="features" className="py-16 md:py-20 bg-white dark:bg-gray-800 scroll-mt-10">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Section Heading */}
        <div className="text-center md:text-left space-y-3 mb-12 max-w-xl md:max-w-3xl">
          <div className="text-xs uppercase font-extrabold tracking-widest text-primary dark:text-blue-400">
            {t.section_feat_label}
          </div>
          <h2 className="font-heading font-bold text-2.5xl sm:text-3.5xl text-gray-900 dark:text-white leading-tight">
            {t.section_feat_title}
          </h2>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuresList.map((feat, idx) => (
            <div
              key={idx}
              className="p-6 md:p-8 bg-gray-50 dark:bg-gray-850 border border-gray-150 dark:border-gray-700/60 rounded-2xl shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all flex flex-col group select-text"
            >
              <div className={`w-12 h-12 flex items-center justify-center rounded-xl text-2xl mb-5 shadow-sm transform group-hover:rotate-6 transition-transform ${feat.bgColor}`}>
                {feat.icon}
              </div>
              <h3 className="font-heading font-bold text-base sm:text-lg text-gray-900 dark:text-white mb-2 leading-snug">
                {feat.title}
              </h3>
              <p className="text-gray-500 dark:text-gray-400 text-xs sm:text-sm leading-relaxed">
                {feat.desc}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
