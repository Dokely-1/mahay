import React, { useState, useEffect } from 'react';
import { ACCESS_CODES, COURSES_DATA, TRANSLATIONS } from '../data';
import { Language, Course } from '../types';

interface StudentPortalProps {
  lang: Language;
}

export default function StudentPortal({ lang }: StudentPortalProps) {
  const t = TRANSLATIONS[lang];

  // Logic & credentials States
  const [accessCode, setAccessCode] = useState('');
  const [loggedInCourse, setLoggedInCourse] = useState<string | null>(null);
  const [watchedVideos, setWatchedVideos] = useState<Set<number>>(new Set());
  const [activeTab, setActiveTab] = useState<'videos' | 'pdfs'>('videos');
  
  // Security protection states (Brute force lockout)
  const [attempts, setAttempts] = useState(0);
  const [lockoutActive, setLockoutActive] = useState(false);
  const [lockoutTimer, setLockoutTimer] = useState(60);
  const [errorMessage, setErrorMessage] = useState('');
  const [shakeActive, setShakeActive] = useState(false);

  // Video modal player playback states
  const [playingVideoIdx, setPlayingVideoIndex] = useState<number | null>(null);
  const [videoModalOpen, setVideoModalOpen] = useState(false);

  // Restore session or lockout timers from storage on mount
  useEffect(() => {
    // Restore session if token exists
    const savedCourse = localStorage.getItem('rekany-student-course');
    if (savedCourse && COURSES_DATA[savedCourse]) {
      setLoggedInCourse(savedCourse);
      const savedProgress = localStorage.getItem(`rekany-progress-${savedCourse}`);
      if (savedProgress) {
        setWatchedVideos(new Set(JSON.parse(savedProgress)));
      }
    }

    // Check if lockout was active
    const savedLockoutEnd = localStorage.getItem('rekany-lockout-time-end');
    if (savedLockoutEnd) {
      const remainingSeconds = Math.ceil((parseInt(savedLockoutEnd, 10) - Date.now()) / 1000);
      if (remainingSeconds > 0) {
        setLockoutActive(true);
        setLockoutTimer(remainingSeconds);
      }
    }
  }, []);

  // Lockout countdown timer loop
  useEffect(() => {
    if (!lockoutActive) return;

    const timer = setInterval(() => {
      setLockoutTimer((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setLockoutActive(false);
          setAttempts(0);
          setErrorMessage('');
          localStorage.removeItem('rekany-lockout-time-end');
          return 60;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [lockoutActive]);

  // Handle Login Code Submission
  const handleVerifyCode = () => {
    if (lockoutActive) return;

    const code = accessCode.trim().toUpperCase();
    const courseId = ACCESS_CODES[code];

    if (!courseId) {
      // Failed login attempt
      setAttempts((prev) => {
        const nextAttempts = prev + 1;
        setShakeActive(true);
        setTimeout(() => setShakeActive(false), 500);

        if (nextAttempts >= 5) {
          const endTime = Date.now() + 60 * 1000;
          localStorage.setItem('rekany-lockout-time-end', endTime.toString());
          setLockoutActive(true);
          setLockoutTimer(60);
          setErrorMessage('');
          return nextAttempts;
        }

        const remaining = 5 - nextAttempts;
        setErrorMessage(
          lang === 'fr'
            ? `❌ Code invalide. ${remaining} tentative${remaining > 1 ? 's' : ''} restante${remaining > 1 ? 's' : ''}.`
            : lang === 'mg'
            ? `❌ Code tsy mety. ${remaining} fanandramana sisa voatandrina.`
            : `❌ Invalid code. ${remaining} attempt${remaining !== 1 ? 's' : ''} left.`
        );
        return nextAttempts;
      });
      return;
    }

    // Success Authentication
    setAttempts(0);
    setErrorMessage('');
    setLoggedInCourse(courseId);
    localStorage.setItem('rekany-student-course', courseId);
    
    // Restore specific course progress
    const savedProgress = localStorage.getItem(`rekany-progress-${courseId}`);
    if (savedProgress) {
      setWatchedVideos(new Set(JSON.parse(savedProgress)));
    } else {
      setWatchedVideos(new Set());
    }

    setAccessCode('');

    // Trigger feedback sound or alert toast
    const msg = lang === 'fr' 
      ? '✅ Accès accordé — Bienvenue dans votre cours !' 
      : lang === 'mg'
      ? '✅ Tafiditra soa aman-tsara ianao !'
      : '✅ Access granted — Welcome to your student space!';
    
    // Dispatch custom toast event to App tree
    window.dispatchEvent(new CustomEvent('rekany-toast', { detail: msg }));
  };

  const handleLogout = () => {
    setLoggedInCourse(null);
    setWatchedVideos(new Set());
    localStorage.removeItem('rekany-student-course');
    const msg = lang === 'fr' ? '👋 Déconnexion réussie' : lang === 'mg' ? '👋 Tafavoaka soa aman-tsara' : '👋 Logged out successfully';
    window.dispatchEvent(new CustomEvent('rekany-toast', { detail: msg }));
  };

  // Video progress trackers
  const activeCourse: Course | undefined = loggedInCourse ? COURSES_DATA[loggedInCourse] : undefined;
  const totalVideos = activeCourse ? activeCourse.videos.length : 0;
  const watchedCount = watchedVideos.size;
  const progressPct = totalVideos > 0 ? Math.round((watchedCount / totalVideos) * 100) : 0;

  // Mark video as watched and trigger Modal play
  const handleOpenVideo = (idx: number) => {
    setPlayingVideoIndex(idx);
    setVideoModalOpen(true);

    // Save watched index
    if (loggedInCourse) {
      const updatedProgress = new Set(watchedVideos);
      updatedProgress.add(idx);
      setWatchedVideos(updatedProgress);
      localStorage.setItem(`rekany-progress-${loggedInCourse}`, JSON.stringify([...updatedProgress]));
    }
  };

  const handlePrevVideo = () => {
    if (playingVideoIdx !== null && playingVideoIdx > 0) {
      handleOpenVideo(playingVideoIdx - 1);
    }
  };

  const handleNextVideo = () => {
    if (playingVideoIdx !== null && activeCourse && playingVideoIdx < activeCourse.videos.length - 1) {
      handleOpenVideo(playingVideoIdx + 1);
    }
  };

  return (
    <section id="access-portal" className="py-16 md:py-20 bg-gray-50 dark:bg-gray-900 scroll-mt-10 border-t border-gray-150 dark:border-gray-800">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 md:px-8">
        
        {/* If logged out, show entering verification form */}
        {!loggedInCourse ? (
          <div>
            <div className="text-center space-y-3 mb-10 max-w-xl mx-auto">
              <div className="text-xs uppercase font-extrabold tracking-widest text-primary dark:text-blue-400">
                🔐 Espace Étudiant
              </div>
              <h2 className="font-heading font-extrabold text-2.5xl sm:text-3.5xl text-gray-900 dark:text-white leading-tight">
                {lang === 'fr' ? 'Accéder à mes cours' : lang === 'mg' ? 'Hiditra amin\'ny fianarako' : 'Access My Courses'}
              </h2>
              <p className="text-gray-500 dark:text-gray-400 text-sm sm:text-base leading-relaxed">
                {lang === 'fr'
                  ? "Entrez votre code d'accès reçu par email après la validation de votre paiement MVola."
                  : lang === 'mg'
                  ? "Ampidiro ny kaody fahazoan-dalana azonao tamin'ny alalan'ny mailaka rehefa voamarina ny MVola."
                  : "Enter your access code received by email upon verification of your MVola submission."
                }
              </p>
            </div>

            {/* Login Card Panel */}
            <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700/80 p-8 rounded-3xl shadow-sm max-w-lg mx-auto text-center select-text">
              <div className="text-4xl mb-3 select-none">🎒</div>
              <h3 className="font-heading font-extrabold text-base sm:text-lg text-gray-900 dark:text-white mb-2 leading-snug">
                {lang === 'fr' ? "Code d'activation" : lang === 'mg' ? "Kaody Fampidirana" : "Activation Code"}
              </h3>
              <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 leading-relaxed max-w-xs mx-auto mb-6">
                {lang === 'fr' 
                  ? "Format du code reçu : LP-XXXX-XXXX" 
                  : lang === 'mg'
                  ? "Ohatra ny kaody alefa : LP-XXXX-XXXX"
                  : "Format of received key: LP-XXXX-XXXX"
                }
              </p>

              {/* Code Entering Inputs Wrapper */}
              <div className="flex flex-col sm:flex-row gap-3 items-stretch w-full mb-4">
                <input
                  type="text"
                  value={accessCode}
                  onChange={(e) => setAccessCode(e.target.value)}
                  disabled={lockoutActive}
                  placeholder="EX: LP-MKTG-2025"
                  className={`flex-1 px-4 py-3.5 rounded-2xl border-2 dark:border-gray-700 bg-gray-50 dark:bg-gray-950 font-heading font-black text-center text-base sm:text-lg tracking-widest text-gray-950 dark:text-white uppercase focus:outline-none focus:border-primary transition-all uppercase placeholder:tracking-normal placeholder:font-sans placeholder:text-sm ${
                    shakeActive ? 'animate-shake border-red-500' : 'border-gray-200'
                  }`}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleVerifyCode();
                  }}
                />
                <button
                  onClick={handleVerifyCode}
                  disabled={lockoutActive || !accessCode.trim()}
                  className="px-6 py-4 bg-primary dark:bg-blue-600 font-extrabold text-white text-sm tracking-wider uppercase rounded-2xl shadow-md hover:bg-primary-dark transition-all select-none border-none shrink-0 disabled:opacity-50 cursor-pointer disabled:cursor-not-allowed"
                >
                  ▶ {lang === 'fr' ? 'Accéder' : lang === 'mg' ? 'Hiditra' : 'Unlock'}
                </button>
              </div>

              {/* Failed authentication logs warning */}
              {errorMessage && (
                <div className="text-xs sm:text-sm text-red-500 font-semibold p-3.5 rounded-xl bg-red-50 dark:bg-red-950/20 border border-red-150 dark:border-red-900/40 text-center animate-pulse">
                  {errorMessage}
                </div>
              )}

              {/* Lockdown active blocks */}
              {lockoutActive && (
                <div className="text-xs sm:text-sm text-amber-600 dark:text-yellow-400 font-semibold p-4 rounded-xl bg-amber-50 dark:bg-amber-950/20 border border-amber-150 dark:border-amber-900/40 text-center space-y-1">
                  <div>🔒 {lang === 'fr' ? "Trop de tentatives échouées !" : "Betsaka loatra ny andrana diso !"}</div>
                  <p className="text-xs text-gray-500 normal-case">
                    {lang === 'fr' 
                      ? `Votre session est bloquée par sécurité. Réessayez dans ${lockoutTimer} secondes.` 
                      : `Azo antoka fa hovahana ny kôra afaka ${lockoutTimer} segondra.`
                    }
                  </p>
                </div>
              )}

              {/* Student login tips to aid navigation */}
              <div className="mt-8 pt-6 border-t border-gray-150 dark:border-gray-700/80 text-left space-y-2">
                <p className="text-[11px] text-gray-400 dark:text-gray-500 leading-relaxed font-semibold text-center">
                  💡 {lang === 'fr' 
                    ? "Le code d'accès est envoyé uniquement à votre adresse email après validation de votre inscription." 
                    : lang === 'mg'
                    ? "Ny kaody fidirana dia alefa amin'ny mailaka ihany rehefa voamarina ny fisoratana anarana."
                    : "The access code is sent strictly to your email address after registration validation."
                  }
                </p>
              </div>

            </div>
          </div>
        ) : (
          /* Locked In View - Course Curriculum list */
          <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700/80 rounded-3xl p-5 sm:p-8 shadow-md">
            
            {/* Class course title & Logout headers wrapper */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-gray-150 dark:border-gray-700 mb-6 select-text">
              <div>
                <h3 className="font-heading font-extrabold text-xl sm:text-2xl text-gray-900 dark:text-white leading-tight">
                  {activeCourse?.title}
                </h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                  {activeCourse?.desc}
                </p>
              </div>
              <div className="flex items-center gap-2.5 flex-wrap shrink-0">
                <span className="bg-emerald-100 dark:bg-emerald-950/40 text-[#059669] dark:text-[#10b981] font-bold text-xs py-1.5 px-3.5 rounded-lg border border-emerald-250 dark:border-emerald-900/20 select-none">
                  ✅ Access Verified
                </span>
                <button
                  onClick={handleLogout}
                  className="bg-gray-50 dark:bg-gray-700 hover:bg-red-50 dark:hover:bg-red-950/20 hover:text-red-600 dark:hover:text-red-400 border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-300 font-bold text-xs py-1.5 px-3.5 rounded-lg cursor-pointer select-none transition-all"
                >
                  🚪 {lang === 'fr' ? 'Déconnexion' : 'Hiala'}
                </button>
              </div>
            </div>

            {/* Curriculum progress state bar */}
            <div className="space-y-2 mb-6">
              <div className="flex justify-between items-center text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-widest select-none">
                <span>📈 Progression globale</span>
                <span className="font-mono text-primary dark:text-blue-400">
                  {watchedCount} / {totalVideos} ({progressPct}%)
                </span>
              </div>
              <div className="h-2.5 w-full bg-gray-100 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-full overflow-hidden select-none">
                <div
                  className="h-full bg-gradient-to-r from-primary to-blue-500 rounded-full transition-all duration-500"
                  style={{ width: `${progressPct}%` }}
                />
              </div>
            </div>

            {/* Course Curriculum navigation tab links */}
            <div className="flex border-b border-gray-150 dark:border-gray-700 mb-6 select-none bg-gray-50 dark:bg-gray-950 p-1 rounded-xl w-fit">
              <button
                onClick={() => setActiveTab('videos')}
                className={`px-5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'videos'
                    ? 'bg-white dark:bg-gray-800 text-primary dark:text-blue-400 shadow-sm'
                    : 'text-gray-400 dark:text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
                }`}
              >
                🎬 Vidéos ({totalVideos})
              </button>
              <button
                onClick={() => setActiveTab('pdfs')}
                className={`px-5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'pdfs'
                    ? 'bg-white dark:bg-gray-800 text-primary dark:text-blue-400 shadow-sm'
                    : 'text-gray-400 dark:text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
                }`}
              >
                📄 PDF & Ressources ({activeCourse?.pdfs.length || 0})
              </button>
            </div>

            {/* Tabs content rendering conditional blocks */}
            {activeTab === 'videos' ? (
              <div className="space-y-2.5 select-text animate-fadeIn">
                {activeCourse?.videos.map((vid, vIdx) => {
                  const isWatched = watchedVideos.has(vIdx);
                  return (
                    <div
                      key={vIdx}
                      onClick={() => handleOpenVideo(vIdx)}
                      className="group border border-gray-200 dark:border-gray-750/70 p-4 rounded-xl flex items-center justify-between gap-4 hover:border-primary dark:hover:border-blue-400 bg-gray-50/50 hover:bg-white dark:bg-gray-850 dark:hover:bg-gray-800 cursor-pointer transition-all"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-extrabold select-none transition-colors border ${
                            isWatched
                              ? 'bg-emerald-500 border-emerald-500 text-white shadow-sm shadow-emerald-500/15'
                              : 'bg-white dark:bg-gray-800 border-gray-250 dark:border-gray-700 text-primary dark:text-blue-400'
                          }`}
                        >
                          {isWatched ? '✓' : vIdx + 1}
                        </div>
                        <div className="space-y-0.5">
                          <div className="text-xs sm:text-sm font-bold text-gray-900 dark:text-white leading-snug group-hover:text-primary dark:group-hover:text-blue-400 transition-colors">
                            {vid.title}
                          </div>
                          <div className="text-[10px] sm:text-xs text-gray-400 dark:text-gray-500 font-medium">
                            ⏱ {vid.duration}
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenVideo(vIdx);
                        }}
                        className="w-8 h-8 rounded-full bg-primary/10 dark:bg-blue-500/10 text-primary dark:text-blue-400 group-hover:bg-primary group-hover:text-white dark:group-hover:bg-blue-600 flex items-center justify-center transition-all select-none border-none shrink-0"
                      >
                        ▶
                      </button>
                    </div>
                  );
                })}
              </div>
            ) : (
              /* PDF TAB list rendering block */
              <div className="space-y-3 select-text animate-fadeIn">
                {activeCourse?.pdfs.map((pdf, pIdx) => (
                  <div
                    key={pIdx}
                    className="border border-gray-200 dark:border-gray-750/70 p-5 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:shadow-sm bg-gray-50/20 dark:bg-gray-850/40"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-red-100 dark:bg-red-950/40 text-red-500 rounded-xl flex items-center justify-center text-xl shrink-0 select-none">
                        📄
                      </div>
                      <div>
                        <div className="text-xs sm:text-sm font-bold text-gray-900 dark:text-white leading-tight">
                          {pdf.title}
                        </div>
                        <div className="text-[10px] sm:text-xs text-gray-400 dark:text-gray-500 font-semibold tracking-wide uppercase mt-0.5 select-none">
                          {pdf.pages} • {pdf.size}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        const msg = lang === 'fr' 
                          ? `📄 "${pdf.title}" — Lien de téléchargement simulé.` 
                          : `📄 "${pdf.title}" — Nalaarina.`;
                        window.dispatchEvent(new CustomEvent('rekany-toast', { detail: msg }));
                      }}
                      className="w-full sm:w-auto px-5 py-2.5 bg-red-650 hover:bg-red-700 text-white font-bold text-xs rounded-xl cursor-pointer select-none transition-all flex items-center justify-center gap-1.5 border-none"
                    >
                      ⬇ Télécharger
                    </button>
                  </div>
                ))}
              </div>
            )}

          </div>
        )}

      </div>

      {/* Embedded custom video popup modal */}
      {videoModalOpen && playingVideoIdx !== null && activeCourse && (
        <div className="fixed inset-0 z-100 flex items-center justify-center bg-black/90 p-4 select-text">
          <div className="fixed inset-0" onClick={() => setVideoModalOpen(false)} />
          <div className="bg-gray-900 dark:bg-gray-950 text-white rounded-2xl w-full max-w-4xl overflow-hidden relative shadow-2xl z-110 flex flex-col select-text">
            
            {/* Header section info */}
            <div className="flex items-center justify-between p-4 border-b border-white/10 select-text">
              <div className="text-xs sm:text-sm font-extrabold line-clamp-1 pr-6 flex items-center gap-3">
                <span className="bg-primary/20 text-primary-light border border-primary/30 px-2 py-0.5 rounded text-[10px] uppercase shrink-0 select-none">
                  {lang === 'fr' ? 'Lecture' : 'Mandeha'}
                </span>
                <span>{activeCourse.videos[playingVideoIdx].title}</span>
              </div>
              <button
                onClick={() => setVideoModalOpen(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white cursor-pointer select-none transition-all text-sm font-extrabold font-sans border-none"
              >
                ✕
              </button>
            </div>

            {/* Responsive iFrame element */}
            <div className="relative pb-[56.25%] bg-black h-0 select-none">
              <iframe
                src={`${activeCourse.videos[playingVideoIdx].url}?autoplay=1`}
                className="absolute inset-0 w-full h-full border-none"
                allow="autoplay; fullscreen"
                allowFullScreen
                title="RekANY courses viewer player"
              />
            </div>

            {/* Bottom playback switches navigation */}
            <div className="flex items-center justify-between p-4 bg-gray-950/70 border-t border-white/5 select-none">
              <button
                onClick={handlePrevVideo}
                disabled={playingVideoIdx === 0}
                className="px-4 py-2 bg-white/10 text-white hover:bg-white/25 text-xs font-bold rounded-lg disabled:opacity-30 disabled:cursor-not-allowed select-none transition-all border-none cursor-pointer"
              >
                ← {lang === 'fr' ? 'Précédent' : 'Aloha'}
              </button>
              
              <span className="text-[11px] font-bold text-gray-400 tracking-wider">
                {playingVideoIdx + 1} / {totalVideos}
              </span>

              <button
                onClick={handleNextVideo}
                disabled={playingVideoIdx === totalVideos - 1}
                className="px-4 py-2 bg-white/10 text-white hover:bg-white/25 text-xs font-bold rounded-lg disabled:opacity-30 disabled:cursor-not-allowed select-none transition-all border-none cursor-pointer"
              >
                {lang === 'fr' ? 'Suivant' : 'Manaraka'} →
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
}
