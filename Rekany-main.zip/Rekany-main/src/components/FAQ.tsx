import React, { useState } from 'react';
import { FAQS, TRANSLATIONS } from '../data';
import { Language } from '../types';

interface FAQProps {
  lang: Language;
}

export default function FAQ({ lang }: FAQProps) {
  const t = TRANSLATIONS[lang];
  const [openId, setOpenId] = useState<string | null>(null);

  const toggleFaq = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  return (
    <section id="faq" className="py-16 md:py-20 bg-gray-50 dark:bg-gray-900 scroll-mt-10 border-t border-gray-150 dark:border-gray-800">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 md:px-8">
        
        {/* Section Heading */}
        <div className="text-center space-y-3 mb-12 max-w-xl md:max-w-3xl mx-auto">
          <div className="text-xs uppercase font-extrabold tracking-widest text-primary dark:text-blue-400">
            FAQ
          </div>
          <h2 className="font-heading font-black text-2.5xl sm:text-3.5xl text-gray-900 dark:text-white leading-tight">
            {t.faq_title}
          </h2>
        </div>

        {/* FAQ Accordion List layout */}
        <div className="space-y-4">
          {FAQS.map((item) => {
            const isOpen = openId === item.id;
            return (
              <div
                key={item.id}
                className="bg-white dark:bg-gray-800 border border-gray-250 dark:border-gray-700/80 rounded-2xl overflow-hidden transition-all duration-300 shadow-sm"
              >
                {/* Header question click button */}
                <button
                  onClick={() => toggleFaq(item.id)}
                  className="w-full px-6 py-5 text-left flex items-center justify-between gap-4 font-bold text-gray-900 dark:text-white font-heading text-xs sm:text-sm hover:text-primary dark:hover:text-blue-400 transition-colors cursor-pointer select-none border-none outline-none"
                >
                  <span className="leading-snug">{t[item.questionKey as keyof typeof t]}</span>
                  <span className={`text-lg text-primary dark:text-blue-400 font-sans transition-transform duration-300 font-light select-none ${
                    isOpen ? 'rotate-45' : 'rotate-0'
                  }`}>
                    ➕
                  </span>
                </button>

                {/* Smooth togglable answer panels */}
                <div
                  className={`transition-all duration-300 ease-in-out overflow-hidden select-text ${
                    isOpen ? 'max-h-[350px] opacity-100 border-t border-gray-100 dark:border-gray-700' : 'max-h-0 opacity-0'
                  }`}
                >
                  <p className="p-6 text-gray-500 dark:text-gray-400 text-xs sm:text-sm leading-relaxed font-medium">
                    {t[item.answerKey as keyof typeof t]}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
