import React from 'react';
import { TRANSLATIONS } from '../data';
import { Language } from '../types';

interface PricingProps {
  lang: Language;
  openEnrollModal: (courseName?: string) => void;
}

export default function Pricing({ lang, openEnrollModal }: PricingProps) {
  const t = TRANSLATIONS[lang];

  return (
    <section id="pricing" className="py-16 md:py-20 bg-white dark:bg-gray-800 scroll-mt-10">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Section Heading */}
        <div className="text-center space-y-3 mb-12 max-w-xl md:max-w-3xl mx-auto">
          <div className="text-xs uppercase font-extrabold tracking-widest text-primary dark:text-blue-400">
            {t.section_pricing_label}
          </div>
          <h2 className="font-heading font-bold text-2.5xl sm:text-3.5xl text-gray-900 dark:text-white leading-tight">
            {t.section_pricing_title}
          </h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm sm:text-base leading-relaxed">
            {t.section_pricing_sub}
          </p>
        </div>

        {/* Pricing Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto items-stretch">
          
          {/* Card 1: Individual Course option */}
          <div className="bg-white dark:bg-gray-850 border-2 border-gray-200 dark:border-gray-700/60 rounded-3xl p-8 flex flex-col justify-between hover:shadow-lg transition-shadow select-text">
            <div>
              <div className="text-[10px] font-black uppercase text-gray-400 dark:text-gray-500 tracking-wider mb-2">
                {t.plan1_name}
              </div>
              <div className="font-heading font-black text-4xl text-gray-900 dark:text-white flex items-baseline gap-2 mb-1.5 leading-none">
                <span>50 000</span>
                <span className="text-lg font-bold text-gray-500 dark:text-gray-400">Ar</span>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 font-bold uppercase tracking-wider mb-6">
                {t.plan1_period}
              </p>

              {/* Items List */}
              <ul className="space-y-3 mb-8 border-t border-gray-100 dark:border-gray-700 pt-6 select-none">
                <li className="flex items-start gap-3 text-xs sm:text-sm text-gray-600 dark:text-gray-300 font-medium">
                  <span className="text-emerald-500 font-bold select-none">✓</span>
                  <span>{t.plan1_f1}</span>
                </li>
                <li className="flex items-start gap-3 text-xs sm:text-sm text-gray-600 dark:text-gray-300 font-medium">
                  <span className="text-emerald-500 font-bold select-none">✓</span>
                  <span>{t.plan1_f2}</span>
                </li>
                <li className="flex items-start gap-3 text-xs sm:text-sm text-gray-600 dark:text-gray-300 font-medium">
                  <span className="text-emerald-500 font-bold select-none">✓</span>
                  <span>{t.plan1_f3}</span>
                </li>
                <li className="flex items-start gap-3 text-xs sm:text-sm text-gray-600 dark:text-gray-300 font-medium">
                  <span className="text-emerald-500 font-bold select-none">✓</span>
                  <span>{t.plan1_f4}</span>
                </li>
                <li className="flex items-start gap-3 text-[#059669] dark:text-[#10b981] font-bold">
                  <span className="text-emerald-500 font-bold select-none">✓</span>
                  <span>{t.plan1_f5}</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => openEnrollModal()}
              className="w-full py-3.5 bg-transparent border-2 border-primary dark:border-blue-500 text-primary dark:text-blue-400 rounded-xl text-sm font-bold hover:bg-primary/5 hover:scale-[1.01] transition-all text-center select-none cursor-pointer"
            >
              {t.plan1_btn}
            </button>
          </div>

          {/* Card 2: Full Access (Recommended) */}
          <div className="bg-white dark:bg-gray-850 border-2 border-primary dark:border-blue-600 rounded-3xl p-8 flex flex-col justify-between hover:shadow-2xl transition-all relative overflow-hidden select-text">
            {/* Recommendation badge */}
            <div className="absolute top-5 -right-9 bg-primary dark:bg-blue-600 text-white font-heading font-black text-[9px] uppercase tracking-wider py-1.5 px-10 transform rotate-45 select-none text-center shadow-sm">
              {t.recommended}
            </div>

            <div>
              <div className="text-[10px] font-black uppercase text-primary dark:text-blue-400 tracking-wider mb-2">
                {t.plan2_name}
              </div>
              <div className="font-heading font-black text-4xl text-gray-900 dark:text-white flex items-baseline gap-2 mb-1.5 leading-none">
                <span>300 000</span>
                <span className="text-lg font-bold text-gray-500 dark:text-gray-400">Ar</span>
              </div>
              <p className="text-xs text-primary/80 dark:text-blue-400/80 font-bold uppercase tracking-wider mb-6">
                {t.plan2_period}
              </p>

              {/* Items List */}
              <ul className="space-y-3 mb-8 border-t border-primary/10 dark:border-gray-700 pt-6 select-none animate-fadeIn">
                <li className="flex items-start gap-3 text-xs sm:text-sm text-gray-600 dark:text-gray-300 font-semibold">
                  <span className="text-emerald-500 font-bold select-none">✓</span>
                  <span className="text-primary dark:text-blue-400">{t.plan2_f1}</span>
                </li>
                <li className="flex items-start gap-3 text-xs sm:text-sm text-gray-600 dark:text-gray-300 font-medium">
                  <span className="text-emerald-500 font-bold select-none">✓</span>
                  <span>{t.plan2_f2}</span>
                </li>
                <li className="flex items-start gap-3 text-xs sm:text-sm text-gray-600 dark:text-gray-300 font-medium">
                  <span className="text-emerald-500 font-bold select-none">✓</span>
                  <span>{t.plan2_f3}</span>
                </li>
                <li className="flex items-start gap-3 text-xs sm:text-sm text-gray-600 dark:text-gray-300 font-medium">
                  <span className="text-emerald-500 font-bold select-none">✓</span>
                  <span>{t.plan2_f4}</span>
                </li>
                <li className="flex items-start gap-3 text-xs sm:text-sm text-gray-600 dark:text-gray-300 font-medium">
                  <span className="text-emerald-500 font-bold select-none">✓</span>
                  <span>{t.plan2_f5}</span>
                </li>
                <li className="flex items-start gap-3 text-[#059669] dark:text-[#10b981] font-bold">
                  <span className="text-emerald-500 font-bold select-none">✓</span>
                  <span>{t.plan2_f6}</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => openEnrollModal("Accès Complet — 6 Cours")}
              className="w-full py-3.5 bg-primary dark:bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-primary-dark hover:scale-[1.01] transition-all text-center shadow-lg shadow-blue-500/10 select-none cursor-pointer border-none"
            >
              {t.plan2_btn}
            </button>
          </div>

        </div>

      </div>
    </section>
  );
}
