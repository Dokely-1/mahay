export interface Video {
  title: string;
  duration: string;
  url: string;
}

export interface Pdf {
  title: string;
  pages: string;
  size: string;
  url: string;
}

export interface Course {
  title: string;
  desc: string;
  videos: Video[];
  pdfs: Pdf[];
}

export interface CourseCatalog {
  [key: string]: Course;
}

export interface Testimonial {
  name: string;
  stars: number;
  text: string;
  avatar: string;
  course: string;
  color: string;
}

export interface FAQItem {
  id: string;
  questionKey: string;
  answerKey: string;
}

export type Language = 'fr' | 'mg' | 'en';

export interface TranslationSchema {
  nav_menu: string;
  nav_courses: string;
  nav_why: string;
  nav_pricing: string;
  nav_payment: string;
  nav_faq: string;
  nav_courses_list: string;
  course_marketing: string;
  course_digital: string;
  course_reseau: string;
  course_info: string;
  course_dev: string;
  course_bureau: string;
  lang_title: string;
  dark_mode: string;
  hero_badge: string;
  hero_title: string;
  hero_desc: string;
  hero_btn1: string;
  hero_btn2: string;
  stat_formations: string;
  stat_online: string;
  stat_price: string;
  stat_access: string;
  hero_card_title: string;
  c1_title: string;
  c2_title: string;
  c3_title: string;
  c4_title: string;
  c5_title: string;
  c6_title: string;
  c1_desc: string;
  c2_desc: string;
  c3_desc: string;
  c4_desc: string;
  c5_desc: string;
  c6_desc: string;
  section_courses_label: string;
  section_courses_title: string;
  section_courses_sub: string;
  filter_all: string;
  filter_marketing: string;
  filter_digital: string;
  filter_reseau: string;
  filter_info: string;
  filter_dev: string;
  filter_bureau: string;
  badge_bestseller: string;
  badge_popular: string;
  cat_marketing: string;
  cat_digital: string;
  cat_reseau: string;
  cat_info: string;
  cat_dev: string;
  cat_bureau: string;
  videos: string;
  lifetime: string;
  enroll: string;
  section_feat_label: string;
  section_feat_title: string;
  feat1_title: string;
  feat1_desc: string;
  feat2_title: string;
  feat2_desc: string;
  feat3_title: string;
  feat3_desc: string;
  feat4_title: string;
  feat4_desc: string;
  feat5_title: string;
  feat5_desc: string;
  feat6_title: string;
  feat6_desc: string;
  section_pricing_label: string;
  section_pricing_title: string;
  section_pricing_sub: string;
  plan1_name: string;
  plan1_period: string;
  plan1_f1: string;
  plan1_f2: string;
  plan1_f3: string;
  plan1_f4: string;
  plan1_f5: string;
  plan1_btn: string;
  plan2_name: string;
  plan2_period: string;
  plan2_f1: string;
  plan2_f2: string;
  plan2_f3: string;
  plan2_f4: string;
  plan2_f5: string;
  plan2_f6: string;
  plan2_btn: string;
  recommended: string;
  section_pay_label: string;
  section_pay_title: string;
  section_pay_sub: string;
  mvola_title: string;
  mvola_sub: string;
  step1_title: string;
  step1_desc: string;
  step2_title: string;
  step2_desc: string;
  step3_title: string;
  step3_desc: string;
  pay_note: string;
  confirm_pay: string;
  faq_title: string;
  faq1_q: string;
  faq1_a: string;
  faq2_q: string;
  faq2_a: string;
  faq3_q: string;
  faq3_a: string;
  faq4_q: string;
  faq4_a: string;
  faq5_q: string;
  faq5_a: string;
  footer_desc: string;
  footer_courses: string;
  footer_platform: string;
  footer_contact: string;
  footer_how: string;
  footer_cert: string;
  footer_email: string;
  footer_legal: string;
  footer_rights: string;
  footer_made: string;
  cta_signup: string;
  search_placeholder: string;
  form_name: string;
  form_name_ph: string;
  form_email: string;
  form_phone: string;
  form_course: string;
  form_txn: string;
  form_submit: string;
  success_title: string;
  success_desc: string;
  close: string;
  toast_lang?: string;
}
