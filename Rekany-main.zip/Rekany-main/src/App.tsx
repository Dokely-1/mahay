/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import CountdownBanner from './components/CountdownBanner';
import CoursesGrid from './components/CoursesGrid';
import Features from './components/Features';
import Testimonials from './components/Testimonials';
import Pricing from './components/Pricing';
import Payment from './components/Payment';
import StudentPortal from './components/StudentPortal';
import FAQ from './components/FAQ';
import Footer from './components/Footer';
import FeedbackPopups from './components/FeedbackPopups';
import { Language } from './types';
import { TRANSLATIONS } from './data';

export default function App() {
  // Global States
  const [lang, setLangState] = useState<Language>('fr');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [searchQuery, setSearchQuery] = useState('');
  const [splashVisible, setSplashVisible] = useState(true);

  // Enrolment Modal States
  const [enrollModalOpen, setEnrollModalOpen] = useState(false);
  const [enrollCourse, setEnrollCourse] = useState('');
  const [enrollName, setEnrollName] = useState('');
  const [enrollEmail, setEnrollEmail] = useState('');
  const [enrollPhone, setEnrollPhone] = useState('');
  const [enrollTxn, setEnrollTxn] = useState('');
  const [enrollSuccess, setEnrollSuccess] = useState(false);
  const [enrollSubmitting, setEnrollSubmitting] = useState(false);

  // Restore States on Mount
  useEffect(() => {
    // Restore Language
    try {
      const savedLang = localStorage.getItem('rekany-lang') as Language;
      if (savedLang && ['fr', 'mg', 'en'].includes(savedLang)) {
        setLangState(savedLang);
        document.documentElement.lang = savedLang;
      }
    } catch (e) {}

    // Restore Theme
    try {
      const savedTheme = localStorage.getItem('rekany-theme') as 'light' | 'dark';
      if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        setTheme('dark');
        document.documentElement.setAttribute('data-theme', 'dark');
        document.documentElement.classList.add('dark');
      } else {
        setTheme('light');
        document.documentElement.setAttribute('data-theme', 'light');
        document.documentElement.classList.remove('dark');
      }
    } catch (e) {}

    // Fade out splash screen after 900ms
    const splashTimer = setTimeout(() => {
      setSplashVisible(false);
    }, 900);

    return () => clearTimeout(splashTimer);
  }, []);

  // Update Language
  const setLang = (newLang: Language) => {
    setLangState(newLang);
    document.documentElement.lang = newLang;
    try {
      localStorage.setItem('rekany-lang', newLang);
    } catch (e) {}

    // Trigger toast indicating language shift
    const toastMsg = TRANSLATIONS[newLang]?.toast_lang || 
      (newLang === 'fr' ? "Langue changée en Français" : newLang === 'mg' ? "Fiteny novaina ho Malagasy" : "Language changed to English");
    triggerToast(toastMsg);
  };

  // Toggle Dark/Light Theme Mode
  const toggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
    document.documentElement.setAttribute('data-theme', nextTheme);
    try {
      localStorage.setItem('rekany-theme', nextTheme);
    } catch (e) {}

    if (nextTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  // Helper to dispatch global toasts
  const triggerToast = (message: string) => {
    window.dispatchEvent(new CustomEvent('rekany-toast', { detail: message }));
  };

  // Handle Smooth Scroll
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Open/Close Enrolment modal block
  const openEnrollModal = (courseName?: string) => {
    setEnrollSuccess(false);
    setEnrollName('');
    setEnrollEmail('');
    setEnrollPhone('');
    setEnrollTxn('');
    
    if (courseName) {
      // Find relative matched index in select dropdown
      const matched = [
        'Booster Page de Vente',
        'Marketing Digital',
        'Maintenance Réseau',
        'Maintenance Informatique',
        'Développement Web',
        'Bureautique Avancée',
        'Accès Complet'
      ].find(term => courseName.includes(term));
      
      setEnrollCourse(matched || '');
    } else {
      setEnrollCourse('');
    }

    setEnrollModalOpen(true);
  };

  const closeEnrollModal = () => {
    setEnrollModalOpen(false);
  };

  // Handle Form Submission with Formspree
  const handleSubmitEnrollForm = (e: React.FormEvent) => {
    e.preventDefault();

    if (!enrollName.trim() || !enrollEmail.trim() || !enrollCourse || !enrollTxn.trim()) {
      triggerToast('⚠️ Veuillez remplir tous les champs obligatoires (*)');
      return;
    }

    // Validation email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(enrollEmail)) {
      triggerToast('⚠️ Adresse email invalide. Ex: votre@email.com');
      return;
    }

    setEnrollSubmitting(true);

    const FORMSPREE_ID = 'mpqejryo';

    fetch(`https://formspree.io/f/${FORMSPREE_ID}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        _subject: `🎓 Nouvelle inscription Rek'ANY — ${enrollCourse}`,
        nom: enrollName,
        email: enrollEmail,
        telephone: enrollPhone,
        cours: enrollCourse,
        transaction: enrollTxn,
        _replyto: enrollEmail
      })
    })
      .then((res) => {
        setEnrollSubmitting(false);
        if (res.ok) {
          setEnrollSuccess(true);
        } else {
          throw new Error('Formspree dispatch error');
        }
      })
      .catch((err) => {
        setEnrollSubmitting(false);
        console.error('Formspree error:', err);
        triggerToast('⚠️ Problème d\'envoi du formulaire. Veuillez contacter le support.');
      });
  };

  const t = TRANSLATIONS[lang];

  return (
    <div className="font-sans min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      
      {/* Dynamic Reading scroll indicator */}
      <div className="read-progress" id="readProgress" />

      {/* Splash screen mounting display */}
      {splashVisible && (
        <div
          id="splash"
          className="fixed inset-0 bg-gradient-to-br from-blue-950 via-primary to-blue-800 z-100 flex flex-col items-center justify-center select-none"
        >
          <div className="font-heading text-4xl font-extrabold text-white mb-2 tracking-tight">
            Rek'ANY<span className="text-accent animate-ping">.</span>MG
          </div>
          <div className="text-xs text-yellow-300/80 font-bold uppercase tracking-widest mt-1">
            🇲🇬 Plateforme N°1 de formation à Madagascar
          </div>
          <div className="w-12 h-12 border-4 border-white/20 border-t-yellow-300 rounded-full animate-spin mt-8" />
        </div>
      )}

      {/* Header element navigation bar */}
      <Header
        lang={lang}
        setLang={setLang}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        theme={theme}
        toggleTheme={toggleTheme}
        openEnrollModal={openEnrollModal}
        scrollToSection={scrollToSection}
      />

      {/* Hero section */}
      <Hero
        lang={lang}
        openEnrollModal={openEnrollModal}
        scrollToSection={scrollToSection}
      />

      {/* URGENT EMERGENCY COUNTDOWN BANNER (PLACED STRATEGICALLY BELOW THE HERO WITH A PRO DESIGN) */}
      <CountdownBanner
        lang={lang}
        scrollToSection={scrollToSection}
      />

      {/* Main Grid display of Courses */}
      <CoursesGrid
        lang={lang}
        searchQuery={searchQuery}
        openEnrollModal={openEnrollModal}
      />

      {/* Features showcase information section */}
      <Features lang={lang} />

      {/* Testimonials list and mounting statistics animated rows */}
      <Testimonials lang={lang} />

      {/* Clear Transparent Plans Pricing sections */}
      <Pricing
        lang={lang}
        openEnrollModal={openEnrollModal}
      />

      {/* Payment MVola instructions panel */}
      <Payment
        lang={lang}
        openEnrollModal={openEnrollModal}
      />

      {/* Secured interactive Student Study curriculum portal */}
      <StudentPortal lang={lang} />

      {/* Standard Accordion FAQ list */}
      <FAQ lang={lang} />

      {/* Footer section maps */}
      <Footer
        lang={lang}
        scrollToSection={scrollToSection}
        openEnrollModal={openEnrollModal}
      />

      {/* Exit popups, floats and standard social verification triggers */}
      <FeedbackPopups
        lang={lang}
        scrollToSection={scrollToSection}
      />

      {/* CHECKOUT PAYMENT CONFIRMATION ENROLMENT MODAL */}
      {enrollModalOpen && (
        <div className="fixed inset-0 z-100 flex items-center justify-center bg-black/60 backdrop-blur-[2px] p-4 select-text">
          <div className="fixed inset-0" onClick={closeEnrollModal} />
          <div className="bg-white dark:bg-gray-800 text-gray-900 dark:text-white rounded-3xl p-6 sm:p-8 w-full max-w-md relative z-110 shadow-2xl overflow-y-auto max-h-[90vh] select-text">
            
            {/* Close */}
            <button
              onClick={closeEnrollModal}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 text-lg font-bold font-sans cursor-pointer select-none bg-transparent border-none"
            >
              ✕
            </button>

            {/* If Form is NOT submitted successfully yet */}
            {!enrollSuccess ? (
              <form onSubmit={handleSubmitEnrollForm} className="space-y-4 select-text">
                <div className="space-y-1 pr-6">
                  <h3 className="font-heading font-black text-xl sm:text-2xl text-gray-950 dark:text-white leading-tight">
                    {lang === 'fr' ? 'Finaliser mon inscription' : 'Fonosana ny fampidirana'}
                  </h3>
                  <p className="text-gray-400 dark:text-gray-500 text-xs font-semibold leading-relaxed">
                    {lang === 'fr' 
                      ? "Envoyez le paiement via MVola, puis confirmez votre reçu d'activation."
                      : "Alefaso aloha ny fandoavana MVola, avy eo fenoy ity takelaka ity."
                    }
                  </p>
                </div>

                {/* MVola Account Details */}
                <div className="p-4 bg-gradient-to-br from-[#E60026] to-[#C20020] text-white rounded-2xl shadow-sm text-left select-text relative overflow-hidden">
                  <div className="absolute -right-8 -bottom-8 w-24 h-24 rounded-full bg-white/5 pointer-events-none" />
                  <div className="text-[10px] uppercase font-bold tracking-widest text-white/70 leading-none mb-2">
                    Numéro MVola à créditer
                  </div>
                  <div className="font-heading font-black text-xl tracking-widest leading-none mb-1.5 selection:bg-white selection:text-red-650">
                    034 56 897 87
                  </div>
                  <div className="text-xs text-white/90 font-medium">
                    {enrollCourse.includes('Complet') ? 'Pack complet : 300 000 Ar' : 'Frais par cours : 50 000 Ar'}
                  </div>
                </div>

                <div className="space-y-3 pt-2 select-text">
                  {/* Name field */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-gray-400 uppercase tracking-widest">
                      {t.form_name}
                    </label>
                    <input
                      type="text"
                      required
                      value={enrollName}
                      onChange={(e) => setEnrollName(e.target.value)}
                      placeholder="Ex: Rakoto Jean"
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-250 dark:border-gray-700 bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:border-primary transition-all font-semibold"
                    />
                  </div>

                  {/* Email field */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-gray-400 uppercase tracking-widest">
                      {t.form_email}
                    </label>
                    <input
                      type="email"
                      required
                      value={enrollEmail}
                      onChange={(e) => setEnrollEmail(e.target.value)}
                      placeholder="votre@email.com"
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-250 dark:border-gray-700 bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:border-primary transition-all font-semibold"
                    />
                  </div>

                  {/* Phone field */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-gray-400 uppercase tracking-widest">
                      {t.form_phone}
                    </label>
                    <input
                      type="tel"
                      value={enrollPhone}
                      onChange={(e) => setEnrollPhone(e.target.value)}
                      placeholder="Ex: 034 56 897 87"
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-250 dark:border-gray-700 bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:border-primary transition-all font-semibold"
                    />
                  </div>

                  {/* Course select drop selection */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-gray-400 uppercase tracking-widest">
                      {t.form_course}
                    </label>
                    <select
                      required
                      value={enrollCourse}
                      onChange={(e) => setEnrollCourse(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-250 dark:border-gray-700 bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:border-primary transition-all font-semibold cursor-pointer"
                    >
                      <option value="" disabled>-- Sélectionnez un cours --</option>
                      <option value="Booster Page de Vente">Booster Page de Vente — 50 000 Ar</option>
                      <option value="Marketing Digital">Marketing Digital — 50 000 Ar</option>
                      <option value="Maintenance Réseau">Maintenance Réseau — 50 000 Ar</option>
                      <option value="Maintenance Informatique">Maintenance Informatique — 50 000 Ar</option>
                      <option value="Développement Web">Développement Web — 50 000 Ar</option>
                      <option value="Bureautique Avancée">Bureautique Avancée — 50 000 Ar</option>
                      <option value="Accès Complet">Accès Complet — 6 Cours — 300 000 Ar</option>
                    </select>
                  </div>

                  {/* Transaction ID Receipt input references */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-gray-400 uppercase tracking-widest text-red-500">
                      {t.form_txn}
                    </label>
                    <input
                      type="text"
                      required
                      value={enrollTxn}
                      onChange={(e) => setEnrollTxn(e.target.value)}
                      placeholder="Ex: MVOLA20261105XXXX"
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-250 dark:border-gray-750 bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:border-red-500 transition-all font-semibold uppercase font-mono tracking-wider placeholder:tracking-normal placeholder:font-sans"
                    />
                  </div>
                </div>

                <div className="pt-4">
                  <button
                    type="submit"
                    disabled={enrollSubmitting}
                    className="w-full py-4 bg-primary dark:bg-blue-600 hover:bg-primary-dark text-white font-bold text-sm rounded-xl tracking-wider shadow-lg shadow-blue-500/10 transition-all select-none border-none shrink-0 disabled:opacity-50 cursor-pointer disabled:cursor-not-allowed"
                  >
                    {enrollSubmitting ? '⏳ Transmettons...' : t.form_submit}
                  </button>
                </div>
              </form>
            ) : (
              /* If Form details submitted successfully */
              <div className="py-8 text-center space-y-4 select-text animate-fadeIn">
                <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-950/40 text-[#059669] dark:text-[#10b981] rounded-full flex items-center justify-center text-3xl mx-auto shadow-inner select-none">
                  ✓
                </div>
                <h3 className="font-heading font-black text-xl sm:text-2xl text-gray-950 dark:text-white leading-tight">
                  {t.success_title}
                </h3>
                <p className="text-gray-500 dark:text-gray-400 text-xs sm:text-sm font-medium leading-relaxed max-w-xs mx-auto">
                  {t.success_desc}
                  <br />
                  <span className="block mt-3 font-semibold text-gray-700 dark:text-gray-300">
                    💡 WhatsApp : <strong className="font-bold">034 56 897 87</strong>
                  </span>
                </p>
                <div className="pt-4">
                  <button
                    onClick={closeEnrollModal}
                    className="w-full py-3.5 bg-primary dark:bg-blue-600 text-white font-bold text-xs rounded-xl uppercase tracking-wider hover:bg-primary-dark shadow-md select-none border-none cursor-pointer"
                  >
                    {t.close}
                  </button>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
}
